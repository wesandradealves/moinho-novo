/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/

;// external ["wp","element"]
const external_wp_element_namespaceObject = window["wp"]["element"];
;// external "React"
const external_React_namespaceObject = window["React"];
var external_React_default = /*#__PURE__*/__webpack_require__.n(external_React_namespaceObject);
;// external ["wp","i18n"]
const external_wp_i18n_namespaceObject = window["wp"]["i18n"];
;// ./src/icons/check.jsx
var _excluded = ["fill"];
var _jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/check.jsx",
  _this = undefined;
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var CheckIcon = function CheckIcon(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? "#1ABC9C" : _ref$fill,
    delegated = _objectWithoutProperties(_ref, _excluded);
  return wp.element.createElement("svg", _extends({
    width: "12",
    height: "13",
    viewBox: "0 0 12 13",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, delegated, {
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }
  }), wp.element.createElement("path", {
    d: "M10.2422 2.36554C10.5156 2.63898 10.7617 2.93585 10.9805 3.25616C11.1914 3.57648 11.3711 3.91632 11.5195 4.2757C11.6758 4.63507 11.7969 5.01007 11.8828 5.4007C11.9609 5.79132 12 6.19366 12 6.60773C12 7.02179 11.9609 7.42413 11.8828 7.81476C11.7969 8.20538 11.6758 8.58038 11.5195 8.93976C11.3711 9.29913 11.1914 9.63898 10.9805 9.95929C10.7617 10.2796 10.5156 10.5765 10.2422 10.8499C9.96875 11.1234 9.67188 11.3694 9.35156 11.5882C9.03125 11.7991 8.69141 11.9788 8.33203 12.1273C7.97266 12.2835 7.59766 12.4046 7.20703 12.4905C6.81641 12.5687 6.41406 12.6077 6 12.6077C5.17188 12.6077 4.39453 12.4515 3.66797 12.139C2.93359 11.8265 2.29297 11.4007 1.74609 10.8616C1.20703 10.3148 0.78125 9.67413 0.46875 8.93976C0.15625 8.2132 0 7.43585 0 6.60773C0 5.7796 0.15625 5.00226 0.46875 4.2757C0.78125 3.54132 1.20703 2.9046 1.74609 2.36554C2.29297 1.81866 2.93359 1.38898 3.66797 1.07648C4.39453 0.763977 5.17188 0.607727 6 0.607727C6.41406 0.607727 6.81641 0.64679 7.20703 0.724915C7.59766 0.810852 7.97266 0.931946 8.33203 1.0882C8.69141 1.23663 9.03125 1.41632 9.35156 1.62726C9.67188 1.84601 9.96875 2.0921 10.2422 2.36554ZM8.49609 5.5882C8.53516 5.54913 8.56641 5.50226 8.58984 5.44757C8.61328 5.39288 8.625 5.33429 8.625 5.27179C8.625 5.20929 8.61328 5.1507 8.58984 5.09601C8.56641 5.04132 8.53516 4.99445 8.49609 4.95538L8.14453 4.60382C8.10547 4.56476 8.05859 4.53351 8.00391 4.51007C7.94922 4.48663 7.89062 4.47491 7.82812 4.47491C7.76562 4.47491 7.70703 4.48663 7.65234 4.51007C7.59766 4.53351 7.55078 4.56476 7.51172 4.60382L5.0625 7.06476L4.06641 6.06866C4.01953 6.0296 3.96875 5.99835 3.91406 5.97491C3.86719 5.95148 3.8125 5.93976 3.75 5.93976C3.6875 5.93976 3.62891 5.95148 3.57422 5.97491C3.51953 5.99835 3.47266 6.0296 3.43359 6.06866L3.08203 6.42023C3.04297 6.45929 3.01172 6.50616 2.98828 6.56085C2.96484 6.61554 2.95312 6.67413 2.95312 6.73663C2.95312 6.79132 2.96484 6.84601 2.98828 6.9007C3.01172 6.95538 3.04297 7.00226 3.08203 7.04132L4.57031 8.5296C4.63281 8.5921 4.70312 8.64288 4.78125 8.68195C4.86719 8.72101 4.96094 8.74054 5.0625 8.74054C5.15625 8.74054 5.24219 8.72101 5.32031 8.68195C5.40625 8.64288 5.48047 8.5921 5.54297 8.5296L8.49609 5.5882Z",
    fill: fill,
    __self: _this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/review.jsx
var review_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/review.jsx",
  review_this = undefined;
function _objectDestructuringEmpty(t) { if (null == t) throw new TypeError("Cannot destructure " + t); }
function review_extends() { return review_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, review_extends.apply(null, arguments); }

var ReviewIcon = function ReviewIcon(_ref) {
  var delegated = review_extends({}, (_objectDestructuringEmpty(_ref), _ref));
  return wp.element.createElement("svg", review_extends({
    width: "17",
    height: "35",
    viewBox: "0 0 17 35",
    xmlns: "http://www.w3.org/2000/svg"
  }, delegated, {
    __self: review_this,
    __source: {
      fileName: review_jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }
  }), wp.element.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M11.4466 34.3577C10.7799 34.3577 10.0466 34.2243 9.44657 33.891C8.84657 33.5577 8.24657 33.1577 7.77991 32.6243C8.77991 31.891 9.9799 31.491 11.1799 31.6243C12.3799 31.7577 13.5132 32.3577 14.3132 33.291C13.5132 34.0243 12.5132 34.3577 11.4466 34.3577ZM13.5799 28.7577C13.5799 27.691 13.9132 26.691 14.5799 25.8243C15.5132 26.6243 16.1132 27.7577 16.2466 28.9577C16.3799 30.1577 16.0466 31.4243 15.3132 32.4243C14.7799 31.9577 14.3799 31.4243 14.0466 30.7577C13.7132 30.1577 13.5799 29.491 13.5799 28.7577ZM6.51324 30.091C5.84658 29.891 5.24658 29.5577 4.71324 29.1577C4.17991 28.691 3.77991 28.1577 3.44658 27.491C4.57991 27.0243 5.84658 27.0243 6.97991 27.491C8.11324 27.9577 9.04657 28.8243 9.5799 29.9577C8.57991 30.291 7.51324 30.3577 6.51324 30.091ZM9.9132 25.2243C10.1799 24.2243 10.7799 23.291 11.5799 22.691C12.3132 23.691 12.5799 24.9577 12.3799 26.1577C12.1799 27.3577 11.5799 28.491 10.5799 29.2243C10.1799 28.6243 9.9132 27.9577 9.7799 27.291C9.7132 26.6243 9.7799 25.891 9.9132 25.2243ZM1.97991 24.3577C1.44658 23.891 0.979918 23.3577 0.713248 22.691C0.446582 22.0243 0.246582 21.3577 0.246582 20.691C1.44658 20.7577 2.64658 21.2243 3.51325 22.1577C4.37991 23.0243 4.84658 24.2243 4.84658 25.491C3.77991 25.4243 2.77991 25.0243 1.97991 24.3577ZM7.11324 21.4243C7.77991 20.5577 8.71324 20.0243 9.7132 19.8243C9.9132 21.0243 9.7132 22.291 9.04657 23.3577C8.37991 24.4243 7.31324 25.1577 6.11324 25.4243C5.97991 24.7577 5.97991 24.0243 6.17991 23.3577C6.37991 22.5577 6.64658 21.9577 7.11324 21.4243ZM1.17992 17.5577C0.779918 17.0243 0.513248 16.3577 0.379915 15.691C0.246582 15.0243 0.246582 14.291 0.446582 13.6243C1.64658 13.9577 2.57991 14.8243 3.17991 15.891C3.77991 16.9577 3.91325 18.2243 3.64658 19.4243C2.64658 19.091 1.77992 18.4243 1.17992 17.5577ZM6.91324 16.091C7.77991 15.491 8.77991 15.1577 9.8466 15.2243C9.7799 16.4243 9.17991 17.6243 8.24657 18.4243C7.31324 19.2243 6.11324 19.691 4.91324 19.6243C4.97991 18.891 5.17991 18.2243 5.51324 17.6243C5.84658 17.0243 6.31324 16.491 6.91324 16.091ZM1.84658 10.691C1.64658 10.0244 1.57992 9.29099 1.71325 8.62433C1.77992 7.95766 2.04658 7.29099 2.44658 6.69099C3.44658 7.42433 4.11325 8.49099 4.37991 9.69099C4.57991 10.891 4.37991 12.1577 3.71325 13.2243C2.77991 12.6244 2.17991 11.691 1.84658 10.691ZM7.77991 11.091C8.77991 10.7577 9.8466 10.8244 10.8466 11.1577C10.3799 12.291 9.44657 13.2243 8.37991 13.691C7.24657 14.1577 5.97991 14.2243 4.84658 13.7577C5.11324 13.091 5.51324 12.5577 6.04658 12.091C6.51324 11.691 7.11324 11.291 7.77991 11.091ZM4.77991 5.22433C4.57991 3.75767 5.11324 2.35767 5.97991 1.35767C6.84658 2.22433 7.31324 3.42433 7.31324 4.691C7.31324 5.95766 6.84658 7.15766 6.04658 8.02433C5.37991 7.22433 4.91324 6.291 4.77991 5.22433ZM10.5132 6.62433C11.5799 6.491 12.5799 6.69099 13.5132 7.29099C12.8466 8.35766 11.7799 9.09099 10.6466 9.35766C9.44657 9.62432 8.17991 9.42432 7.17991 8.82433C7.57991 8.22433 8.04657 7.75766 8.64657 7.35766C9.17991 6.95766 9.8466 6.75766 10.5132 6.62433ZM11.2466 1.42434C12.0466 0.757665 13.0466 0.424333 14.1132 0.357666C14.0466 1.62433 13.5799 2.75767 12.7132 3.62433C11.8466 4.491 10.6466 4.95766 9.44657 5.02433C9.44657 4.291 9.64657 3.62433 9.9799 3.02433C10.2466 2.35767 10.7132 1.82433 11.2466 1.42434Z",
    __self: review_this,
    __source: {
      fileName: review_jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/star-alt.jsx
var star_alt_excluded = ["fill", "score", "maxStars", "className"];
var star_alt_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/star-alt.jsx",
  star_alt_this = undefined;
function star_alt_extends() { return star_alt_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, star_alt_extends.apply(null, arguments); }
function star_alt_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = star_alt_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function star_alt_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var StarAltIcon = function StarAltIcon(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? "#888888" : _ref$fill,
    _ref$score = _ref.score,
    score = _ref$score === void 0 ? null : _ref$score,
    _ref$maxStars = _ref.maxStars,
    maxStars = _ref$maxStars === void 0 ? 5 : _ref$maxStars,
    _ref$className = _ref.className,
    className = _ref$className === void 0 ? "" : _ref$className,
    delegated = star_alt_objectWithoutProperties(_ref, star_alt_excluded);
  // If score is provided, render multiple stars
  if (score !== null) {
    var normalizedScore = Math.max(0, Math.min(maxStars, parseFloat(score)));
    return wp.element.createElement("div", {
      className: "star-rating ".concat(className),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '2px'
      },
      __self: star_alt_this,
      __source: {
        fileName: star_alt_jsxFileName,
        lineNumber: 15,
        columnNumber: 7
      }
    }, Array.from({
      length: maxStars
    }, function (_, index) {
      var starNumber = index + 1;
      var isFilled = starNumber <= normalizedScore;
      var isPartial = starNumber > normalizedScore && starNumber - 1 < normalizedScore;
      return wp.element.createElement("div", {
        key: index,
        style: {
          position: 'relative',
          display: 'inline-block'
        },
        __self: star_alt_this,
        __source: {
          fileName: star_alt_jsxFileName,
          lineNumber: 22,
          columnNumber: 13
        }
      }, wp.element.createElement("svg", star_alt_extends({
        height: "15",
        viewBox: "0 1 12 12",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
          display: 'block' // Removes baseline spacing issues
        }
      }, delegated, {
        __self: star_alt_this,
        __source: {
          fileName: star_alt_jsxFileName,
          lineNumber: 24,
          columnNumber: 15
        }
      }), wp.element.createElement("path", {
        d: "M11.9883 5.14288H11.9766C11.9844 5.15851 11.9883 5.17413 11.9883 5.18976C11.9961 5.20538 12 5.22101 12 5.23663C12 5.28351 11.9883 5.32648 11.9648 5.36554C11.9492 5.4046 11.9258 5.43976 11.8945 5.47101L8.71875 7.97882L10.1367 11.9866C10.1445 12.0023 10.1484 12.0179 10.1484 12.0335C10.1562 12.0491 10.1602 12.0648 10.1602 12.0804C10.1602 12.1585 10.1289 12.2249 10.0664 12.2796C10.0117 12.3421 9.94531 12.3734 9.86719 12.3734C9.84375 12.3734 9.81641 12.3694 9.78516 12.3616C9.76172 12.3538 9.73828 12.3421 9.71484 12.3265L6 10.0999L2.28516 12.3265C2.26172 12.3421 2.23438 12.3538 2.20312 12.3616C2.17969 12.3694 2.15625 12.3734 2.13281 12.3734C2.05469 12.3734 1.98438 12.3421 1.92188 12.2796C1.86719 12.2249 1.83984 12.1585 1.83984 12.0804C1.83984 12.0648 1.83984 12.0491 1.83984 12.0335C1.84766 12.0179 1.85547 12.0023 1.86328 11.9866L3.28125 7.97882L0.105469 5.47101C0.0742188 5.43976 0.046875 5.4046 0.0234375 5.36554C0.0078125 5.32648 0 5.28351 0 5.23663C0 5.15851 0.0273438 5.0921 0.0820312 5.03741C0.136719 4.98273 0.207031 4.95538 0.292969 4.95538H4.34766L5.73047 1.04132C5.74609 0.978821 5.77734 0.931946 5.82422 0.900696C5.87891 0.861633 5.9375 0.842102 6 0.842102C6.0625 0.842102 6.11719 0.861633 6.16406 0.900696C6.21875 0.931946 6.25391 0.978821 6.26953 1.04132L7.65234 4.94366H11.707C11.7773 4.94366 11.8359 4.9632 11.8828 5.00226C11.9297 5.04132 11.9648 5.0882 11.9883 5.14288Z",
        fill: "#e0e0e0",
        __self: star_alt_this,
        __source: {
          fileName: star_alt_jsxFileName,
          lineNumber: 34,
          columnNumber: 17
        }
      })), (isFilled || isPartial) && wp.element.createElement("svg", star_alt_extends({
        height: "15",
        viewBox: "0 1 12 12",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        style: {
          display: 'block',
          position: 'absolute',
          top: 0,
          left: 0,
          clipPath: isPartial ? "inset(0 ".concat(100 - normalizedScore % 1 * 100, "% 0 0)") : 'none'
        }
      }, delegated, {
        __self: star_alt_this,
        __source: {
          fileName: star_alt_jsxFileName,
          lineNumber: 42,
          columnNumber: 17
        }
      }), wp.element.createElement("path", {
        d: "M11.9883 5.14288H11.9766C11.9844 5.15851 11.9883 5.17413 11.9883 5.18976C11.9961 5.20538 12 5.22101 12 5.23663C12 5.28351 11.9883 5.32648 11.9648 5.36554C11.9492 5.4046 11.9258 5.43976 11.8945 5.47101L8.71875 7.97882L10.1367 11.9866C10.1445 12.0023 10.1484 12.0179 10.1484 12.0335C10.1562 12.0491 10.1602 12.0648 10.1602 12.0804C10.1602 12.1585 10.1289 12.2249 10.0664 12.2796C10.0117 12.3421 9.94531 12.3734 9.86719 12.3734C9.84375 12.3734 9.81641 12.3694 9.78516 12.3616C9.76172 12.3538 9.73828 12.3421 9.71484 12.3265L6 10.0999L2.28516 12.3265C2.26172 12.3421 2.23438 12.3538 2.20312 12.3616C2.17969 12.3694 2.15625 12.3734 2.13281 12.3734C2.05469 12.3734 1.98438 12.3421 1.92188 12.2796C1.86719 12.2249 1.83984 12.1585 1.83984 12.0804C1.83984 12.0648 1.83984 12.0491 1.83984 12.0335C1.84766 12.0179 1.85547 12.0023 1.86328 11.9866L3.28125 7.97882L0.105469 5.47101C0.0742188 5.43976 0.046875 5.4046 0.0234375 5.36554C0.0078125 5.32648 0 5.28351 0 5.23663C0 5.15851 0.0273438 5.0921 0.0820312 5.03741C0.136719 4.98273 0.207031 4.95538 0.292969 4.95538H4.34766L5.73047 1.04132C5.74609 0.978821 5.77734 0.931946 5.82422 0.900696C5.87891 0.861633 5.9375 0.842102 6 0.842102C6.0625 0.842102 6.11719 0.861633 6.16406 0.900696C6.21875 0.931946 6.25391 0.978821 6.26953 1.04132L7.65234 4.94366H11.707C11.7773 4.94366 11.8359 4.9632 11.8828 5.00226C11.9297 5.04132 11.9648 5.0882 11.9883 5.14288Z",
        fill: "#ff7d4a",
        __self: star_alt_this,
        __source: {
          fileName: star_alt_jsxFileName,
          lineNumber: 58,
          columnNumber: 19
        }
      })));
    }));
  }

  // If no score provided, render single star (original behavior)
  return wp.element.createElement("svg", star_alt_extends({
    height: "15",
    viewBox: "0 1 12 12",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg",
    className: className
  }, delegated, {
    __self: star_alt_this,
    __source: {
      fileName: star_alt_jsxFileName,
      lineNumber: 73,
      columnNumber: 5
    }
  }), wp.element.createElement("path", {
    d: "M11.9883 5.14288H11.9766C11.9844 5.15851 11.9883 5.17413 11.9883 5.18976C11.9961 5.20538 12 5.22101 12 5.23663C12 5.28351 11.9883 5.32648 11.9648 5.36554C11.9492 5.4046 11.9258 5.43976 11.8945 5.47101L8.71875 7.97882L10.1367 11.9866C10.1445 12.0023 10.1484 12.0179 10.1484 12.0335C10.1562 12.0491 10.1602 12.0648 10.1602 12.0804C10.1602 12.1585 10.1289 12.2249 10.0664 12.2796C10.0117 12.3421 9.94531 12.3734 9.86719 12.3734C9.84375 12.3734 9.81641 12.3694 9.78516 12.3616C9.76172 12.3538 9.73828 12.3421 9.71484 12.3265L6 10.0999L2.28516 12.3265C2.26172 12.3421 2.23438 12.3538 2.20312 12.3616C2.17969 12.3694 2.15625 12.3734 2.13281 12.3734C2.05469 12.3734 1.98438 12.3421 1.92188 12.2796C1.86719 12.2249 1.83984 12.1585 1.83984 12.0804C1.83984 12.0648 1.83984 12.0491 1.83984 12.0335C1.84766 12.0179 1.85547 12.0023 1.86328 11.9866L3.28125 7.97882L0.105469 5.47101C0.0742188 5.43976 0.046875 5.4046 0.0234375 5.36554C0.0078125 5.32648 0 5.28351 0 5.23663C0 5.15851 0.0273438 5.0921 0.0820312 5.03741C0.136719 4.98273 0.207031 4.95538 0.292969 4.95538H4.34766L5.73047 1.04132C5.74609 0.978821 5.77734 0.931946 5.82422 0.900696C5.87891 0.861633 5.9375 0.842102 6 0.842102C6.0625 0.842102 6.11719 0.861633 6.16406 0.900696C6.21875 0.931946 6.25391 0.978821 6.26953 1.04132L7.65234 4.94366H11.707C11.7773 4.94366 11.8359 4.9632 11.8828 5.00226C11.9297 5.04132 11.9648 5.0882 11.9883 5.14288Z",
    fill: fill,
    __self: star_alt_this,
    __source: {
      fileName: star_alt_jsxFileName,
      lineNumber: 81,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/google.jsx
var google_excluded = ["fill"];
var google_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/google.jsx",
  google_this = undefined;
function google_extends() { return google_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, google_extends.apply(null, arguments); }
function google_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = google_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function google_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var GoogleIcon = function GoogleIcon(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? "#1a1a1a" : _ref$fill,
    delegated = google_objectWithoutProperties(_ref, google_excluded);
  return wp.element.createElement("svg", google_extends({
    width: "57",
    height: "15",
    viewBox: "0 0 57 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, delegated, {
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }
  }), wp.element.createElement("path", {
    d: "M41.2468 8.92073L42.4261 9.71793C42.1099 10.1979 41.6814 10.591 41.1788 10.8619C40.6763 11.1328 40.1154 11.2731 39.5462 11.2703C37.5818 11.2703 36.1187 9.72893 36.1187 7.76741C36.1187 5.67965 37.5968 4.26367 39.3803 4.26367C41.1638 4.26367 42.0535 5.71164 42.3381 6.49286L42.4933 6.89105L37.8706 8.82728C38.2225 9.53023 38.7703 9.88713 39.5462 9.88713C40.3222 9.88713 40.8592 9.49903 41.2468 8.91652V8.92073ZM37.6225 7.65797L40.709 6.35733C40.5388 5.9221 40.0318 5.6123 39.4267 5.6123C38.6566 5.6123 37.5868 6.30513 37.6225 7.65797Z",
    fill: fill,
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M33.8921 0.692627H35.381V10.9504H33.8921V0.692627Z",
    fill: fill,
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M31.5451 4.53643H32.9825V10.766C32.9825 13.3513 31.4778 14.4162 29.7001 14.4162C28.0245 14.4162 27.0161 13.273 26.6394 12.3445L27.9573 11.7889C28.1955 12.3605 28.769 13.0365 29.7001 13.0365C30.8421 13.0365 31.5451 12.3184 31.5451 10.9756V10.4705H31.4936C31.1525 10.8915 30.4977 11.2678 29.6736 11.2678C27.9473 11.2678 26.3647 9.74152 26.3647 7.77498C26.3647 5.80845 27.9473 4.2561 29.6736 4.2561C30.496 4.2561 31.1525 4.62819 31.4936 5.03732H31.5451V4.53222V4.53643ZM31.6488 7.77751C31.6488 6.54001 30.8371 5.6384 29.803 5.6384C28.769 5.6384 27.8834 6.54001 27.8834 7.77751C27.8834 8.99986 28.7623 9.88212 29.8064 9.88212C30.8504 9.88212 31.6521 8.99649 31.6521 7.77751H31.6488Z",
    fill: fill,
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M18.1919 7.75147C18.1919 9.77193 16.6407 11.2543 14.7377 11.2543C12.8347 11.2543 11.2852 9.76513 11.2852 7.75147C11.2852 5.72179 12.8364 4.24268 14.7385 4.24268C16.6407 4.24268 18.1919 5.72179 18.1919 7.75147ZM16.6822 7.75147C16.6822 6.48871 15.7826 5.6275 14.7377 5.6275C13.6928 5.6275 12.794 6.49292 12.794 7.75147C12.794 9.01002 13.692 9.87463 14.7377 9.87463C15.7834 9.87463 16.6798 8.99991 16.6798 7.75147H16.6822Z",
    fill: fill,
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M25.7368 7.76961C25.7368 9.79003 24.1865 11.2725 22.2834 11.2725C20.3804 11.2725 18.8301 9.79003 18.8301 7.76961C18.8301 5.74919 20.3812 4.26587 22.2834 4.26587C24.1856 4.26587 25.7368 5.73236 25.7368 7.76961ZM24.2222 7.76961C24.2222 6.50685 23.3225 5.64565 22.2785 5.64565C21.2344 5.64565 20.3339 6.50685 20.3339 7.76961C20.3339 9.03233 21.2336 9.89353 22.2776 9.89353C23.3217 9.89353 24.2222 9.00964 24.2222 7.76961Z",
    fill: fill,
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M5.60718 9.73383C3.44106 9.73383 1.74552 7.9609 1.74552 5.7637C1.74552 3.5665 3.44106 1.79274 5.60718 1.79274C6.59609 1.7794 7.55033 2.16204 8.26295 2.85767L9.30202 1.80369C8.41981 0.950897 7.24629 0.299316 5.60718 0.299316C2.63935 0.299316 0.14209 2.75328 0.14209 5.7637C0.14209 8.77411 2.63935 11.228 5.60718 11.228C7.20977 11.228 8.41981 10.6935 9.36593 9.69673C10.3378 8.71098 10.6374 7.32615 10.6374 6.20398C10.635 5.87515 10.6055 5.54711 10.5494 5.22324H5.60718V6.6813H9.12691C9.024 7.59386 8.73933 8.21766 8.32022 8.64279C7.81396 9.16223 7.01225 9.73723 5.60635 9.73723L5.60718 9.73383Z",
    fill: fill,
    __self: google_this,
    __source: {
      fileName: google_jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/reviews.jsx
var reviews_excluded = ["fill"];
var reviews_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/reviews.jsx",
  reviews_this = undefined;
function reviews_extends() { return reviews_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, reviews_extends.apply(null, arguments); }
function reviews_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = reviews_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function reviews_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var ReviewsIcon = function ReviewsIcon(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? "#1a1a1a" : _ref$fill,
    delegated = reviews_objectWithoutProperties(_ref, reviews_excluded);
  return wp.element.createElement("svg", reviews_extends({
    width: "68",
    height: "12",
    viewBox: "0 0 68 12",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, delegated, {
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }
  }), wp.element.createElement("path", {
    opacity: "0.4",
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M9.68162 2.98071L9.20499 3.21979C10.1342 3.97012 10.5884 4.93933 10.6728 6.11213C10.6023 8.37585 9.53419 9.83079 7.69948 10.4547C5.57977 11.0934 4.23659 10.5766 2.93685 9.25236L2.85498 9.76144L3.38341 10.312C5.22154 12.2276 8.26909 12.2905 10.1846 10.4523C12.1002 8.61416 12.1631 5.56671 10.3249 3.65107L9.68162 2.98071Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    opacity: "0.4",
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M2.5933 9.47791L2.91264 9.19899C1.58587 7.31883 1.53027 4.56624 3.34601 3.05086C4.69195 1.92759 7.36257 1.34536 9.49916 3.22656L9.65864 2.94603L9.13799 2.40336C7.29976 0.48782 4.25231 0.424921 2.33667 2.26314C0.421134 4.10127 0.358329 7.14882 2.19645 9.06436L2.5933 9.47791Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M1.44531 6.37144C1.44531 9.03296 3.60325 11.1909 6.26477 11.1909C8.92676 11.1909 11.0846 9.03296 11.0846 6.37144C11.0846 3.70945 8.92676 1.55151 6.26477 1.55151C3.60325 1.55151 1.44531 3.70945 1.44531 6.37144ZM4.79986 7.24312C4.85052 7.08279 4.79417 6.90804 4.65945 6.80738C4.30274 6.54098 3.59946 6.01577 3.1269 5.66285C3.05869 5.61191 3.0308 5.52301 3.05765 5.44218C3.0845 5.36135 3.16001 5.3069 3.24521 5.3069H5.07679C5.24727 5.3069 5.3985 5.1976 5.4521 5.03585C5.59649 4.59973 5.88348 3.73298 6.07379 3.15844C6.10054 3.07771 6.17597 3.02306 6.26107 3.02297C6.34617 3.02287 6.42187 3.07723 6.44882 3.15787C6.64112 3.73289 6.93152 4.60105 7.07734 5.03699C7.13132 5.19817 7.28226 5.3069 7.45227 5.3069C7.88555 5.3069 8.72022 5.3069 9.2885 5.3069C9.37341 5.3069 9.44893 5.36116 9.47587 5.4418C9.50282 5.52244 9.4753 5.61124 9.40738 5.66238C8.93625 6.01729 8.23259 6.54724 7.87663 6.81535C7.74267 6.9162 7.68698 7.09066 7.73755 7.25043C7.87521 7.68513 8.15128 8.5569 8.3378 9.14576C8.36379 9.22802 8.33343 9.31776 8.26275 9.36729C8.19208 9.41681 8.09749 9.41482 8.02899 9.36226C7.55568 8.9989 6.86416 8.4681 6.50204 8.19022C6.35964 8.08093 6.16155 8.08121 6.01953 8.19107C5.66091 8.46829 4.97879 8.99577 4.50946 9.35865C4.44115 9.4115 4.34638 9.41387 4.27551 9.36435C4.20464 9.31492 4.17409 9.22517 4.20009 9.14282C4.3866 8.55225 4.6623 7.67896 4.79986 7.24312Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M21.0917 9.10085L19.4816 7.02818C20.5154 6.78615 21.2381 6.11128 21.2381 4.99272V4.97361C21.2381 4.41254 21.033 3.91337 20.6864 3.56647C20.2435 3.12362 19.5501 2.85864 18.6848 2.85864H16.1305C15.8795 2.85864 15.6633 3.07273 15.6633 3.33553V9.42915C15.6633 9.69204 15.8795 9.90612 16.1305 9.90612C16.3923 9.90612 16.607 9.69146 16.607 9.42915V7.20539H18.4369L20.3316 9.66684C20.4357 9.80559 20.5762 9.90612 20.7612 9.90612C21.0002 9.90612 21.2381 9.68987 21.2381 9.4385C21.2381 9.31101 21.1838 9.20472 21.0917 9.10085ZM20.2846 5.00281L20.2847 5.02225C20.2847 5.85197 19.5845 6.33946 18.6163 6.33946H16.607V3.74401H18.6261C19.6668 3.74401 20.2846 4.21064 20.2846 5.00281Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 31,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M22.614 9.38051C22.614 9.64298 22.8303 9.85715 23.0812 9.85715H27.371C27.6143 9.85715 27.8087 9.66242 27.8087 9.41914C27.8087 9.17619 27.6144 8.98146 27.371 8.98146H23.5579V6.76637H26.8836C27.127 6.76637 27.3216 6.57198 27.3216 6.3287C27.3216 6.09751 27.127 5.89068 26.8836 5.89068H23.5579V3.73467H27.3224C27.5652 3.73467 27.7604 3.53994 27.7604 3.29665C27.7604 3.05337 27.5652 2.85864 27.3224 2.85864H23.0812C22.8304 2.85864 22.614 3.07273 22.614 3.33562V9.38051Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M31.7765 9.93522L31.8276 9.93505C32.083 9.93063 32.2421 9.7868 32.3431 9.56195L34.9868 3.45532C35.0104 3.39658 35.0223 3.33785 35.0223 3.26735C35.0223 3.02715 34.8192 2.80981 34.5551 2.80981C34.3458 2.80981 34.1789 2.96783 34.0971 3.13061C34.0962 3.13244 34.0954 3.13428 34.0945 3.1362L31.806 8.61801L29.5265 3.15564C29.4453 2.9579 29.2796 2.80981 29.0469 2.80981C28.7836 2.80981 28.5696 3.03816 28.5696 3.27669C28.5696 3.36004 28.5823 3.41928 28.6176 3.49019L31.248 9.56012C31.3397 9.78872 31.5133 9.93522 31.7765 9.93522Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M36.2712 3.2867V9.42896C36.2712 9.69185 36.4875 9.90594 36.7384 9.90594C37.0002 9.90594 37.215 9.69127 37.215 9.42896V3.2867C37.215 3.0244 37.0002 2.80981 36.7384 2.80981C36.4875 2.80981 36.2712 3.02381 36.2712 3.2867Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M43.6622 2.85881L43.6508 2.85864H39.4095C39.1589 2.85864 38.9426 3.07273 38.9426 3.33562V9.38051C38.9426 9.64298 39.1588 9.85715 39.4095 9.85715H43.6995C43.9424 9.85715 44.1371 9.66242 44.1371 9.41914C44.1371 9.17619 43.9424 8.98146 43.6995 8.98146H39.8863V6.76637H43.2117C43.4555 6.76637 43.6497 6.57198 43.6497 6.3287C43.6497 6.09751 43.4555 5.89068 43.2117 5.89068H39.8863V3.73467H43.6508C43.8937 3.73467 44.0888 3.53994 44.0888 3.29665C44.0888 3.05721 43.8997 2.86473 43.6622 2.85881Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 47,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M52.0234 9.94473H52.1035C52.3309 9.93989 52.4944 9.78404 52.5745 9.55494C52.5741 9.55569 54.7583 3.49169 54.7583 3.49169C54.7586 3.49085 54.7588 3.4901 54.7592 3.48927C54.781 3.42252 54.8122 3.34368 54.8122 3.27694C54.8122 3.03791 54.5861 2.81006 54.3352 2.81006C54.1106 2.81006 53.9534 2.95873 53.8821 3.17148C53.8825 3.17056 52.0755 8.36788 52.0755 8.36788L50.3715 3.17165C50.301 2.9594 50.1446 2.81006 49.9092 2.81006H49.8601C49.6126 2.81006 49.468 2.9594 49.3974 3.17165L47.6935 8.36772L45.8962 3.18967C45.8266 2.98084 45.6479 2.81006 45.4143 2.81006C45.1526 2.81006 44.928 3.03682 44.928 3.2867C44.928 3.35453 44.9486 3.42227 44.9711 3.48969L47.1556 9.5551C47.236 9.79522 47.3996 9.94022 47.6266 9.94473H47.7067C47.9338 9.93989 48.0977 9.78395 48.1773 9.55477L49.8604 4.55309L51.5528 9.55494C51.6328 9.78404 51.7967 9.93989 52.0234 9.94473Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 51,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M59.7361 7.9956V8.01504C59.7361 8.64486 59.1602 9.08854 58.3022 9.08854C57.459 9.08854 56.833 8.833 56.2077 8.30321L56.206 8.30162C56.1441 8.24122 56.035 8.19125 55.9136 8.19125C55.6615 8.19125 55.4558 8.3944 55.4558 8.65846C55.4558 8.81497 55.5295 8.94713 55.6371 9.02096C56.413 9.6366 57.2585 9.95447 58.273 9.95447C59.6828 9.95447 60.6896 9.1542 60.6896 7.9372V7.91734C60.6896 6.83608 59.9749 6.24614 58.3985 5.90241C58.3984 5.90241 58.3987 5.90241 58.3985 5.90241C56.9664 5.59539 56.6144 5.27517 56.6144 4.66112V4.64168C56.6144 4.06835 57.1523 3.62691 57.9802 3.62691C58.5957 3.62691 59.1352 3.79795 59.694 4.20501C59.6938 4.20485 59.6941 4.20517 59.694 4.20501C59.7771 4.26475 59.8614 4.28986 59.9694 4.28986C60.2217 4.28986 60.4265 4.08562 60.4265 3.8324C60.4265 3.65428 60.3214 3.52271 60.226 3.45104C60.2255 3.45071 60.225 3.45029 60.2245 3.44996C59.5859 2.99101 58.918 2.76099 57.9997 2.76099C56.6486 2.76099 55.6703 3.59262 55.6703 4.7101V4.72878C55.6703 5.89005 56.4046 6.43069 58.0303 6.78385C58.0301 6.78385 58.0304 6.78385 58.0303 6.78385C59.3943 7.07176 59.7361 7.39231 59.7361 7.9956Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 55,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M61.7639 8.94686L61.7556 8.94678C61.5723 8.94678 61.4417 9.0781 61.4417 9.25514V9.36427C61.4417 9.54106 61.5725 9.67821 61.7556 9.67821C61.9322 9.67821 62.0639 9.54139 62.0639 9.36427C62.0639 9.39313 62.0406 9.41641 62.0118 9.41641C62.0118 9.41641 62.0639 9.41057 62.0639 9.36185V9.25514C62.0639 9.08052 61.9367 8.95087 61.7639 8.94686ZM61.4985 9.41566C61.4956 9.41624 61.4939 9.41641 61.4939 9.41641C61.4955 9.41641 61.4969 9.41583 61.4985 9.41566Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 59,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M62.8764 6.96502V9.41337C62.8764 9.56272 62.992 9.67827 63.1408 9.67827C63.291 9.67827 63.4006 9.56305 63.4006 9.41337V6.96502C63.4006 6.81526 63.285 6.70012 63.1357 6.70012C62.9929 6.70012 62.8764 6.82227 62.8764 6.96502ZM62.8382 5.96702C62.8382 6.12712 62.9691 6.24267 63.1357 6.24267C63.3086 6.24267 63.4384 6.12679 63.4384 5.96702V5.89643C63.4384 5.72982 63.3086 5.62036 63.1357 5.62036C62.9691 5.62036 62.8381 5.72949 62.8381 5.89643L62.8382 5.96702Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 63,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M67.1418 8.19326L67.1419 8.18142C67.1419 7.35662 66.4983 6.66748 65.6231 6.66748C64.7423 6.66748 64.0984 7.36797 64.0984 8.19218V8.20302C64.0984 9.02749 64.7368 9.71654 65.612 9.71654C66.4927 9.71654 67.1414 9.01698 67.1418 8.19326ZM66.6069 8.20302V8.19218C66.6069 7.61634 66.1776 7.14237 65.612 7.14237C65.0312 7.14237 64.6334 7.61617 64.6334 8.18142V8.19218C64.6334 8.76793 65.0576 9.23581 65.6231 9.23581C66.2035 9.23581 66.6069 8.76818 66.6069 8.20302Z",
    fill: fill,
    __self: reviews_this,
    __source: {
      fileName: reviews_jsxFileName,
      lineNumber: 67,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/trustpilot.jsx
var trustpilot_excluded = ["fill"];
var trustpilot_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/trustpilot.jsx",
  trustpilot_this = undefined;
function trustpilot_extends() { return trustpilot_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, trustpilot_extends.apply(null, arguments); }
function trustpilot_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = trustpilot_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function trustpilot_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var TrustPilotIcon = function TrustPilotIcon(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? "#1a1a1a" : _ref$fill,
    delegated = trustpilot_objectWithoutProperties(_ref, trustpilot_excluded);
  return wp.element.createElement("svg", trustpilot_extends({
    width: "57",
    height: "15",
    viewBox: "0 0 57 15",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, delegated, {
    __self: trustpilot_this,
    __source: {
      fileName: trustpilot_jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }
  }), wp.element.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M9.05649 5.7379H14.2201L10.0434 8.98287L11.6383 14.2313L7.46158 10.9864L10.4021 10.1712L10.0434 8.98287L7.46158 10.9864L3.27981 14.2313L4.87974 8.98287L0.697998 5.73257L5.86162 5.7379L7.46155 0.484131L9.05649 5.7379Z",
    fill: fill,
    __self: trustpilot_this,
    __source: {
      fileName: trustpilot_jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M15.2251 4.66162H20.942V5.80189H18.6941V12.2119H17.458V5.80189H15.2201V4.66162H15.2251ZM20.6977 6.74501H21.7544V7.80003H21.7743C21.8092 7.65083 21.874 7.50697 21.9687 7.36843C22.0634 7.22989 22.1781 7.09668 22.3126 6.98479C22.4472 6.86756 22.5967 6.77698 22.7612 6.70238C22.9257 6.63312 23.0951 6.59582 23.2646 6.59582C23.3942 6.59582 23.4889 6.60115 23.5387 6.60647C23.5886 6.6118 23.6384 6.62246 23.6932 6.62779V7.78937C23.6135 7.77339 23.5338 7.76273 23.449 7.75207C23.3643 7.74142 23.2845 7.73609 23.2048 7.73609C23.0154 7.73609 22.836 7.77871 22.6665 7.85864C22.497 7.93857 22.3525 8.06112 22.2279 8.21564C22.1033 8.37549 22.0036 8.56731 21.9288 8.80176C21.8541 9.03621 21.8192 9.30263 21.8192 9.60634V12.2066H20.6928V6.74501H20.6977ZM28.8718 12.2119H27.7653V11.4499H27.7454C27.6058 11.727 27.4015 11.9455 27.1274 12.1107C26.8532 12.2758 26.5741 12.3611 26.29 12.3611C25.6171 12.3611 25.1287 12.1852 24.8296 11.8282C24.5306 11.4712 24.3811 10.9331 24.3811 10.2138V6.74501H25.5075V10.0965C25.5075 10.5761 25.5922 10.9171 25.7667 11.1142C25.9361 11.3114 26.1804 11.4126 26.4894 11.4126C26.7286 11.4126 26.923 11.3753 27.0825 11.2954C27.242 11.2155 27.3716 11.1142 27.4663 10.981C27.566 10.8532 27.6357 10.6933 27.6806 10.5121C27.7255 10.331 27.7454 10.1338 27.7454 9.92072V6.75034H28.8718V12.2119ZM30.7907 10.4589C30.8256 10.8105 30.9502 11.0556 31.1645 11.1995C31.3838 11.338 31.643 11.4126 31.9471 11.4126C32.0517 11.4126 32.1714 11.402 32.3059 11.386C32.4405 11.37 32.5701 11.3327 32.6847 11.2848C32.8043 11.2368 32.899 11.1622 32.9788 11.0663C33.0536 10.9704 33.0884 10.8478 33.0835 10.6933C33.0785 10.5388 33.0236 10.4109 32.924 10.315C32.8243 10.2138 32.6997 10.1392 32.5452 10.0752C32.3907 10.0166 32.2162 9.96332 32.0168 9.92072C31.8175 9.87809 31.6181 9.83013 31.4138 9.78218C31.2044 9.73422 31.0001 9.67028 30.8057 9.60101C30.6113 9.53175 30.4369 9.43583 30.2823 9.31328C30.1278 9.19606 30.0032 9.04154 29.9135 8.85504C29.8188 8.66855 29.774 8.43943 29.774 8.16236C29.774 7.86397 29.8437 7.61886 29.9783 7.41639C30.1129 7.21391 30.2873 7.05406 30.4917 6.9315C30.701 6.80895 30.9303 6.7237 31.1845 6.67041C31.4387 6.62246 31.6829 6.59582 31.9122 6.59582C32.1763 6.59582 32.4305 6.62779 32.6698 6.6864C32.909 6.74501 33.1283 6.84092 33.3227 6.97946C33.5171 7.11267 33.6766 7.2885 33.8062 7.50164C33.9358 7.71477 34.0155 7.97586 34.0504 8.27958H32.8741C32.8193 7.99185 32.6997 7.7947 32.5053 7.69879C32.3109 7.59755 32.0866 7.54959 31.8374 7.54959C31.7577 7.54959 31.663 7.55492 31.5533 7.57091C31.4437 7.58689 31.344 7.61353 31.2443 7.65083C31.1496 7.68813 31.0698 7.74674 31.0001 7.82134C30.9353 7.89594 30.9004 7.99185 30.9004 8.1144C30.9004 8.26359 30.9502 8.38082 31.0449 8.4714C31.1396 8.56198 31.2642 8.63658 31.4187 8.70052C31.5732 8.75913 31.7477 8.81242 31.9471 8.85504C32.1464 8.89767 32.3508 8.94563 32.5601 8.99358C32.7645 9.04154 32.9638 9.10548 33.1632 9.17475C33.3626 9.24401 33.537 9.33992 33.6915 9.46248C33.846 9.58503 33.9706 9.73422 34.0653 9.91542C34.16 10.0965 34.2099 10.3257 34.2099 10.5921C34.2099 10.9171 34.1401 11.1888 34.0005 11.418C33.861 11.6418 33.6816 11.8282 33.4623 11.9668C33.243 12.1053 32.9937 12.2119 32.7246 12.2758C32.4555 12.3398 32.1863 12.3717 31.9221 12.3717C31.5982 12.3717 31.2991 12.3344 31.025 12.2545C30.7509 12.1746 30.5116 12.0574 30.3122 11.9028C30.1129 11.743 29.9534 11.5458 29.8388 11.3114C29.7241 11.0769 29.6643 10.7945 29.6543 10.4695H30.7907V10.4589ZM34.5089 6.74501H35.3612V5.10388H36.4877V6.74501H37.5044V7.64551H36.4877V10.5654C36.4877 10.6933 36.4926 10.7999 36.5026 10.8958C36.5126 10.9864 36.5375 11.0663 36.5724 11.1302C36.6073 11.1942 36.6621 11.2421 36.7369 11.2741C36.8116 11.3061 36.9063 11.3221 37.0359 11.3221C37.1157 11.3221 37.1954 11.3221 37.2752 11.3167C37.3549 11.3114 37.4347 11.3007 37.5144 11.2794V12.2119C37.3898 12.2279 37.2652 12.2385 37.1506 12.2545C37.0309 12.2705 36.9113 12.2758 36.7867 12.2758C36.4877 12.2758 36.2484 12.2439 36.069 12.1853C35.8896 12.1266 35.745 12.0361 35.6453 11.9188C35.5407 11.8016 35.4759 11.6577 35.436 11.4819C35.4011 11.3061 35.3762 11.1036 35.3712 10.8798V7.65616H34.5189V6.74501H34.5089ZM38.3019 6.74501H39.3685V7.48565H39.3885C39.548 7.16595 39.7673 6.94216 40.0514 6.80362C40.3355 6.66509 40.6395 6.59582 40.9734 6.59582C41.3771 6.59582 41.726 6.67041 42.0251 6.82494C42.3241 6.97413 42.5734 7.18194 42.7727 7.44836C42.9721 7.71477 43.1166 8.02382 43.2163 8.37549C43.316 8.72716 43.3658 9.10548 43.3658 9.5051C43.3658 9.87276 43.321 10.2297 43.2313 10.5708C43.1416 10.9171 43.007 11.2208 42.8276 11.4872C42.6481 11.7537 42.4188 11.9615 42.1397 12.1213C41.8606 12.2812 41.5366 12.3611 41.1578 12.3611C40.9934 12.3611 40.8289 12.3451 40.6644 12.3131C40.4999 12.2812 40.3404 12.2279 40.1909 12.1586C40.0414 12.0893 39.8968 11.9988 39.7722 11.8869C39.6427 11.775 39.538 11.6471 39.4483 11.5032H39.4283V14.2313H38.3019V6.74501ZM42.2394 9.48379C42.2394 9.23869 42.2095 8.99891 42.1497 8.76446C42.0899 8.53001 42.0002 8.32754 41.8806 8.14637C41.7609 7.96521 41.6114 7.82134 41.437 7.71477C41.2575 7.60821 41.0532 7.54959 40.8239 7.54959C40.3504 7.54959 39.9915 7.72543 39.7523 8.0771C39.5131 8.42877 39.3934 8.89767 39.3934 9.48379C39.3934 9.76087 39.4233 10.0166 39.4881 10.2511C39.5529 10.4855 39.6427 10.688 39.7722 10.8585C39.8968 11.029 40.0464 11.1622 40.2208 11.2581C40.3953 11.3594 40.5996 11.4073 40.8289 11.4073C41.0881 11.4073 41.3024 11.3487 41.4818 11.2368C41.6613 11.1249 41.8058 10.9757 41.9204 10.7999C42.0351 10.6187 42.1198 10.4162 42.1696 10.1871C42.2145 9.95802 42.2394 9.72357 42.2394 9.48379ZM44.2281 4.66162H45.3545V5.80189H44.2281V4.66162ZM44.2281 6.74501H45.3545V12.2119H44.2281V6.74501ZM46.3613 4.66162H47.4878V12.2119H46.3613V4.66162ZM50.9418 12.3611C50.5331 12.3611 50.1693 12.2865 49.8503 12.1426C49.5313 11.9988 49.2621 11.7963 49.0379 11.5458C48.8185 11.2901 48.6491 10.9864 48.5344 10.6347C48.4198 10.283 48.36 9.89412 48.36 9.47313C48.36 9.05752 48.4198 8.67388 48.5344 8.32221C48.6491 7.97054 48.8185 7.66682 49.0379 7.41106C49.2572 7.1553 49.5313 6.95815 49.8503 6.81428C50.1693 6.67041 50.5331 6.59582 50.9418 6.59582C51.3505 6.59582 51.7144 6.67041 52.0333 6.81428C52.3523 6.95815 52.6215 7.16062 52.8458 7.41106C53.0651 7.66682 53.2345 7.97054 53.3492 8.32221C53.4638 8.67388 53.5236 9.05752 53.5236 9.47313C53.5236 9.89412 53.4638 10.283 53.3492 10.6347C53.2345 10.9864 53.0651 11.2901 52.8458 11.5458C52.6265 11.8016 52.3523 11.9988 52.0333 12.1426C51.7144 12.2865 51.3505 12.3611 50.9418 12.3611ZM50.9418 11.4073C51.191 11.4073 51.4103 11.3487 51.5947 11.2368C51.7792 11.1249 51.9287 10.9757 52.0483 10.7945C52.1679 10.6134 52.2527 10.4056 52.3125 10.1765C52.3673 9.94732 52.3972 9.71291 52.3972 9.47313C52.3972 9.23868 52.3673 9.00957 52.3125 8.77512C52.2576 8.54067 52.1679 8.33819 52.0483 8.15703C51.9287 7.97586 51.7792 7.832 51.5947 7.7201C51.4103 7.60821 51.191 7.54959 50.9418 7.54959C50.6926 7.54959 50.4733 7.60821 50.2889 7.7201C50.1045 7.832 49.9549 7.98119 49.8353 8.15703C49.7157 8.33819 49.631 8.54067 49.5712 8.77512C49.5163 9.00957 49.4864 9.23868 49.4864 9.47313C49.4864 9.71291 49.5163 9.94732 49.5712 10.1765C49.626 10.4056 49.7157 10.6134 49.8353 10.7945C49.9549 10.9757 50.1045 11.1249 50.2889 11.2368C50.4733 11.354 50.6926 11.4073 50.9418 11.4073ZM53.8526 6.74501H54.7049V5.10388H55.8313V6.74501H56.8481V7.64551H55.8313V10.5654C55.8313 10.6933 55.8363 10.7999 55.8463 10.8958C55.8562 10.9864 55.8811 11.0663 55.916 11.1302C55.9509 11.1942 56.0058 11.2421 56.0805 11.2741C56.1553 11.3061 56.25 11.3221 56.3796 11.3221C56.4593 11.3221 56.5391 11.3221 56.6188 11.3167C56.6985 11.3114 56.7783 11.3007 56.858 11.2794V12.2119C56.7334 12.2279 56.6088 12.2385 56.4942 12.2545C56.3746 12.2705 56.255 12.2758 56.1304 12.2758C55.8313 12.2758 55.5921 12.2439 55.4126 12.1853C55.2332 12.1266 55.0887 12.0361 54.989 11.9188C54.8843 11.8016 54.8195 11.6577 54.7796 11.4819C54.7448 11.3061 54.7198 11.1036 54.7148 10.8798V7.65616H53.8625V6.74501H53.8526Z",
    fill: fill,
    __self: trustpilot_this,
    __source: {
      fileName: trustpilot_jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/wpmudev.jsx
var wpmudev_excluded = ["fill"];
var wpmudev_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/icons/wpmudev.jsx",
  wpmudev_this = undefined;
function wpmudev_extends() { return wpmudev_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, wpmudev_extends.apply(null, arguments); }
function wpmudev_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = wpmudev_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function wpmudev_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var WpmudevIcon = function WpmudevIcon(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? "#0C33A9" : _ref$fill,
    delegated = wpmudev_objectWithoutProperties(_ref, wpmudev_excluded);
  return wp.element.createElement("svg", wpmudev_extends({
    width: "76",
    height: "76",
    viewBox: "0 0 76 76",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, delegated, {
    __self: wpmudev_this,
    __source: {
      fileName: wpmudev_jsxFileName,
      lineNumber: 5,
      columnNumber: 5
    }
  }), wp.element.createElement("rect", {
    x: "0.5",
    width: "75",
    height: "76",
    rx: "25.24",
    fill: fill,
    __self: wpmudev_this,
    __source: {
      fileName: wpmudev_jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }), wp.element.createElement("path", {
    d: "M54.8506 51.8092C55.4469 50.7796 55.7577 49.5995 55.7489 48.3987V21.9962H50.9594V48.4031C50.9599 48.6087 50.9196 48.8122 50.8408 49.0009C50.762 49.1896 50.6466 49.3594 50.5016 49.4997C50.1647 49.8023 49.7339 49.9689 49.288 49.9689C48.8422 49.9689 48.4114 49.8023 48.0745 49.4997C47.9307 49.3587 47.8163 49.1886 47.7383 49C47.6603 48.8114 47.6204 48.6083 47.621 48.4031V28.5219C47.6433 27.66 47.4946 26.8025 47.1841 26.0026C46.8736 25.2026 46.4079 24.4773 45.8158 23.8716C44.9336 22.9407 43.803 22.3043 42.5693 22.0443C41.3355 21.7843 40.0549 21.9125 38.892 22.4124C37.7291 22.9123 36.7369 23.761 36.0429 24.8497C35.3489 25.9384 34.9848 27.2172 34.9974 28.5219V48.4031C35.0007 48.6067 34.9642 48.8088 34.89 48.9973C34.8157 49.1858 34.7054 49.3567 34.5655 49.4997C34.4043 49.6589 34.2137 49.7825 34.0051 49.8633C33.7965 49.9441 33.5743 49.9802 33.3519 49.9697C33.1294 49.9818 32.9067 49.9464 32.698 49.8655C32.4892 49.7847 32.2987 49.6602 32.1384 49.4997C31.9934 49.3594 31.8779 49.1896 31.7992 49.0009C31.7204 48.8122 31.68 48.6087 31.6806 48.4031V28.5219C31.7027 27.6604 31.5543 26.8033 31.2446 26.0035C30.9348 25.2038 30.4703 24.4782 29.8797 23.8716C29.2877 23.2555 28.5805 22.7713 27.8015 22.4488C27.0224 22.1263 26.1879 21.9723 25.3493 21.9962C23.6259 21.9752 21.9618 22.6474 20.7067 23.8716C20.0757 24.4542 19.5741 25.1716 19.2364 25.9744C18.8986 26.7772 18.7328 27.6463 18.7503 28.5219V54.9064H23.5441V28.5219C23.5407 28.3183 23.5773 28.1162 23.6515 27.9277C23.7257 27.7392 23.8361 27.5683 23.976 27.4253C24.3128 27.1227 24.7437 26.9561 25.1895 26.9561C25.6354 26.9561 26.0662 27.1227 26.4031 27.4253C26.5474 27.5661 26.6625 27.7361 26.7412 27.9246C26.8199 28.1132 26.8607 28.3164 26.8609 28.5219V48.4031C26.8393 49.2646 26.9879 50.1215 27.2976 50.9212C27.6073 51.7209 28.0716 52.4465 28.6618 53.0535C29.253 53.6631 29.9574 54.1421 30.7324 54.4614C31.5074 54.7806 32.3368 54.9336 33.1705 54.9109C34.897 54.9386 36.5669 54.273 37.8305 53.0535C38.4608 52.4701 38.9623 51.7527 39.3007 50.9502C39.6391 50.1476 39.8064 49.2788 39.7912 48.4031V28.5219C39.8311 28.1353 40.0076 27.7776 40.2866 27.5178C40.5656 27.2579 40.9276 27.1141 41.3027 27.1141C41.6779 27.1141 42.0398 27.2579 42.3188 27.5178C42.5979 27.7776 42.7743 28.1353 42.8143 28.5219V48.4031C42.8042 49.6047 43.1167 50.7855 43.7169 51.8137C44.2828 52.813 45.1171 53.6202 46.1181 54.1366C47.098 54.6457 48.179 54.9108 49.2751 54.9108C50.3712 54.9108 51.4522 54.6457 52.4321 54.1366C53.4404 53.6225 54.2813 52.8133 54.8506 51.8092Z",
    fill: "white",
    __self: wpmudev_this,
    __source: {
      fileName: wpmudev_jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }
  }));
};

;// ./src/icons/index.jsx







;// ./src/components/hero/hero.jsx
var hero_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/hero/hero.jsx",
  hero_this = undefined;



var HeroSection = function HeroSection() {
  return wp.element.createElement("div", {
    className: "cross-sell-hero",
    __self: hero_this,
    __source: {
      fileName: hero_jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-wrapper cross-sell-hero__wrapper",
    __self: hero_this,
    __source: {
      fileName: hero_jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }
  }, wp.element.createElement("h2", {
    __self: hero_this,
    __source: {
      fileName: hero_jsxFileName,
      lineNumber: 9,
      columnNumber: 9
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Explore our powerful WordPress plugins.", "plugin-cross-sell-textdomain")), wp.element.createElement("p", {
    __self: hero_this,
    __source: {
      fileName: hero_jsxFileName,
      lineNumber: 15,
      columnNumber: 9
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Smart, reliable, and completely free - what’s not to love?", "plugin-cross-sell-textdomain"))), wp.element.createElement("div", {
    className: "cross-sell-hero__logo",
    __self: hero_this,
    __source: {
      fileName: hero_jsxFileName,
      lineNumber: 22,
      columnNumber: 7
    }
  }, wp.element.createElement(WpmudevIcon, {
    __self: hero_this,
    __source: {
      fileName: hero_jsxFileName,
      lineNumber: 23,
      columnNumber: 9
    }
  })));
};

;// ./src/components/hero/index.jsx

;// ./src/utils/utm-url.js
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
/*
Usage :
const url = getUtmUrlWithParams('https://wpmudev.com/pricing/', {
  utm_campaign: 'homepage_banner',
  custom_param: 'value123'
});

Or simply :
const url = getUtmUrlWithParams('https://wpmudev.com/pricing/');
*/
var getUtmUrl = function getUtmUrl(url) {
  var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var _ref = window.wpmudev_cross_sell_data || {},
    _ref$utmSource = _ref.utmSource,
    utmSource = _ref$utmSource === void 0 ? '' : _ref$utmSource;
  var defaultParams = {
    utm_source: utmSource,
    utm_medium: 'plugin',
    utm_campaign: 'cross-sell_top-cta',
    utm_content: 'plugins-cross-sell'
  };

  // Merge default params with any overrides
  var mergedParams = _objectSpread(_objectSpread({}, defaultParams), params);
  var urlObj = new URL(url);
  Object.entries(mergedParams).forEach(function (_ref2) {
    var _ref3 = _slicedToArray(_ref2, 2),
      key = _ref3[0],
      value = _ref3[1];
    if (value != null) {
      urlObj.searchParams.set(key, value);
    }
  });
  return urlObj.toString();
};
;// ./src/components/footer/footer.jsx
var footer_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/footer/footer.jsx",
  footer_this = undefined;



var Footer = function Footer() {
  return wp.element.createElement("div", {
    className: "cross-sell-footer",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-wrapper cross-sell-footer__wrapper",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-footer__content",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 9,
      columnNumber: 9
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-footer__title",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 10,
      columnNumber: 11
    }
  }, wp.element.createElement("h2", {
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 11,
      columnNumber: 13
    }
  }, (0,external_wp_i18n_namespaceObject.__)("About WPMU DEV", "plugin-cross-sell-textdomain")), wp.element.createElement("p", {
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Made for web developers, by web developers", "plugin-cross-sell-textdomain"))), wp.element.createElement("div", {
    className: "cross-sell-footer__description",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 19,
      columnNumber: 11
    }
  }, wp.element.createElement("p", {
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 20,
      columnNumber: 13
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Since 2006, our award-winning WordPress plugins, hosting, world beating support and site management tools have helped hundreds of thousands of web developers, freelancers and agencies run and grow their businesses. ", "plugin-cross-sell-textdomain"), wp.element.createElement("a", {
    href: getUtmUrl("https://wpmudev.com/about/", {
      utm_campaign: 'cross-sell_learn-more'
    }),
    target: "_blank",
    className: "cross-sell-link",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 25,
      columnNumber: 15
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Learn more", "plugin-cross-sell-textdomain"))))), wp.element.createElement("div", {
    className: "cross-sell-footer__credits",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 35,
      columnNumber: 9
    }
  }, wp.element.createElement("p", {
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 36,
      columnNumber: 11
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Everything Wordpress found in one place. ", "plugin-cross-sell-textdomain"), wp.element.createElement("a", {
    href: getUtmUrl("https://wpmudev.com/", {
      utm_campaign: 'cross-sell_footer-link'
    }),
    target: "_blank",
    className: "cross-sell-link",
    __self: footer_this,
    __source: {
      fileName: footer_jsxFileName,
      lineNumber: 41,
      columnNumber: 13
    }
  }, (0,external_wp_i18n_namespaceObject.__)("WPMU DEV", "plugin-cross-sell-textdomain"))))));
};

;// ./src/components/footer/index.jsx

;// ./src/components/reviews/review-item.jsx
var review_item_excluded = ["link", "logo", "ratings", "reviews"];
var review_item_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/reviews/review-item.jsx",
  review_item_this = undefined;
function review_item_extends() { return review_item_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, review_item_extends.apply(null, arguments); }
function review_item_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = review_item_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function review_item_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }



var ReviewItem = function ReviewItem(_ref) {
  var link = _ref.link,
    Logo = _ref.logo,
    ratings = _ref.ratings,
    reviews = _ref.reviews,
    delegated = review_item_objectWithoutProperties(_ref, review_item_excluded);
  return wp.element.createElement("div", review_item_extends({
    className: "review"
  }, delegated, {
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }
  }), wp.element.createElement("div", {
    className: "review__image",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }
  }, wp.element.createElement(ReviewIcon, {
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 9,
      columnNumber: 9
    }
  })), wp.element.createElement("div", {
    className: "review__rating",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }
  }, Logo && wp.element.createElement("a", {
    className: "review__reviews",
    href: link,
    target: "_blank",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 13,
      columnNumber: 11
    }
  }, wp.element.createElement("span", {
    className: "review__logo",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 14,
      columnNumber: 11
    }
  }, wp.element.createElement(Logo, {
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }
  }))), ratings && wp.element.createElement("div", {
    className: "review__ratings",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 19,
      columnNumber: 21
    }
  }, wp.element.createElement("a", {
    className: "review__reviews",
    href: link,
    target: "_blank",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 19,
      columnNumber: 54
    }
  }, ratings, " (", reviews, " Reviews)"))), wp.element.createElement("div", {
    className: "review__image review__image--flip",
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 21,
      columnNumber: 7
    }
  }, wp.element.createElement(ReviewIcon, {
    __self: review_item_this,
    __source: {
      fileName: review_item_jsxFileName,
      lineNumber: 22,
      columnNumber: 9
    }
  })));
};

;// ./src/components/reviews/reviews.jsx
var reviews_reviews_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/reviews/reviews.jsx",
  reviews_reviews_this = undefined;
function reviews_reviews_extends() { return reviews_reviews_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, reviews_reviews_extends.apply(null, arguments); }




var REVIEW_ITEMS = [{
  link: "https://www.trustpilot.com/review/wpmudev.com",
  logo: TrustPilotIcon,
  ratings: (0,external_wp_i18n_namespaceObject.__)("4.8/5", "plugin-cross-sell-textdomain"),
  reviews: (0,external_wp_i18n_namespaceObject.__)("3,026+", "plugin-cross-sell-textdomain")
}, {
  link: "https://www.reviews.io/company-reviews/store/wpmudev-com/",
  logo: ReviewsIcon,
  ratings: (0,external_wp_i18n_namespaceObject.__)("4.9/5", "plugin-cross-sell-textdomain"),
  reviews: (0,external_wp_i18n_namespaceObject.__)("1,751", "plugin-cross-sell-textdomain")
}, {
  link: "https://www.google.com/search?q=WPMU+DEV&stick=H4sIAAAAAAAA_-NgU1I1qLAwMzFJTkq0SLY0NDdNMjW0MqgwNk4ySbZMSjQxTjEwNbAwXsTKER7gG6rg4hoGAFY8Y0Y0AAAA&hl=en&mat=CdvqvSC1kKDMElYBNqvzOh6WSjS1JTPgbDKr_wHsjlg-PedU9JwdPCfoAnD-gp_c4yhRTs4ampJofZFKWPiClgM5THRDw4IjNwi1icSMk7AHlnFbFP31PhpLbvH6V0UYHg&authuser=0#lrd=0x8644cba8c9175b51:0x33b4c9ba43d05083,1,,,",
  logo: GoogleIcon,
  ratings: (0,external_wp_i18n_namespaceObject.__)("4.8/5", "plugin-cross-sell-textdomain"),
  reviews: (0,external_wp_i18n_namespaceObject.__)("700+", "plugin-cross-sell-textdomain")
}];
var Reviews = function Reviews() {
  return wp.element.createElement("div", {
    className: "sui-box",
    __self: reviews_reviews_this,
    __source: {
      fileName: reviews_reviews_jsxFileName,
      lineNumber: 29,
      columnNumber: 4
    }
  }, REVIEW_ITEMS && wp.element.createElement("div", {
    className: "cross-sell-footer__reviews",
    __self: reviews_reviews_this,
    __source: {
      fileName: reviews_reviews_jsxFileName,
      lineNumber: 31,
      columnNumber: 11
    }
  }, REVIEW_ITEMS.map(function (item, index) {
    return wp.element.createElement(ReviewItem, reviews_reviews_extends({
      key: index
    }, item, {
      __self: reviews_reviews_this,
      __source: {
        fileName: reviews_reviews_jsxFileName,
        lineNumber: 33,
        columnNumber: 15
      }
    }));
  })));
};

;// ./src/components/reviews/index.jsx

;// ./src/components/button/button.jsx
var button_excluded = ["as", "className", "children"];
var button_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/button/button.jsx",
  button_this = undefined;
function button_extends() { return button_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, button_extends.apply(null, arguments); }
function button_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = button_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function button_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }

var Button = function Button(_ref) {
  var _ref$as = _ref.as,
    as = _ref$as === void 0 ? "button" : _ref$as,
    _ref$className = _ref.className,
    className = _ref$className === void 0 ? "" : _ref$className,
    children = _ref.children,
    delegated = button_objectWithoutProperties(_ref, button_excluded);
  var TagName = as;
  return wp.element.createElement(TagName, button_extends({
    className: "cross-sell-button ".concat(className)
  }, delegated, {
    __self: button_this,
    __source: {
      fileName: button_jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }
  }), children);
};

;// ./src/components/button/index.jsx

;// ./src/components/section/section.jsx
var section_excluded = ["title", "titleUnderline", "className", "tag", "description", "children"];
var section_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/section/section.jsx",
  section_this = undefined;
function section_extends() { return section_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, section_extends.apply(null, arguments); }
function section_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = section_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function section_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }


var Section = function Section(_ref) {
  var title = _ref.title,
    titleUnderline = _ref.titleUnderline,
    _ref$className = _ref.className,
    className = _ref$className === void 0 ? "" : _ref$className,
    tag = _ref.tag,
    description = _ref.description,
    children = _ref.children,
    delegated = section_objectWithoutProperties(_ref, section_excluded);
  return wp.element.createElement("div", section_extends({
    className: "cross-sell-section ".concat(className)
  }, delegated, {
    __self: section_this,
    __source: {
      fileName: section_jsxFileName,
      lineNumber: 14,
      columnNumber: 5
    }
  }), (title || tag || description) && wp.element.createElement("div", {
    className: "cross-sell-section-header-wrapper",
    __self: section_this,
    __source: {
      fileName: section_jsxFileName,
      lineNumber: 16,
      columnNumber: 9
    }
  }, (title || tag) && wp.element.createElement("div", {
    className: "cross-sell-section-header",
    __self: section_this,
    __source: {
      fileName: section_jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }
  }, title && wp.element.createElement("h2", {
    className: "cross-sell-text-center",
    __self: section_this,
    __source: {
      fileName: section_jsxFileName,
      lineNumber: 20,
      columnNumber: 17
    }
  }, title, titleUnderline && wp.element.createElement("span", {
    className: "cross-sell-section-title-underline",
    __self: section_this,
    __source: {
      fileName: section_jsxFileName,
      lineNumber: 23,
      columnNumber: 21
    }
  }, titleUnderline)), tag), description && wp.element.createElement("span", {
    className: "cross-sell-section-description",
    __self: section_this,
    __source: {
      fileName: section_jsxFileName,
      lineNumber: 33,
      columnNumber: 13
    }
  }, description)), children);
};

;// ./src/components/section/index.jsx

;// ./src/components/banners/pro-plugins-banner.jsx
function pro_plugins_banner_typeof(o) { "@babel/helpers - typeof"; return pro_plugins_banner_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, pro_plugins_banner_typeof(o); }
var pro_plugins_banner_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/banners/pro-plugins-banner.jsx",
  pro_plugins_banner_this = undefined;
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == pro_plugins_banner_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(pro_plugins_banner_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }





var ProPluginsBanner = function ProPluginsBanner(_ref) {
  var _ref$href = _ref.href,
    href = _ref$href === void 0 ? "#plans" : _ref$href,
    _ref$targetBlank = _ref.targetBlank,
    targetBlank = _ref$targetBlank === void 0 ? false : _ref$targetBlank;
  var gradId = typeof (external_React_default()).useId === "function" ? external_React_default().useId() : "ppb-grad-" + Math.random().toString(36).slice(2);
  var handleInstallPlugin = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
      return _regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            window.open(href, "_blank");
          case 1:
          case "end":
            return _context.stop();
        }
      }, _callee);
    }));
    return function handleInstallPlugin() {
      return _ref2.apply(this, arguments);
    };
  }();
  return wp.element.createElement(Section, {
    className: "cross-sell-pro-banner",
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 18,
      columnNumber: 5
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-pro-banner__inner",
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 19,
      columnNumber: 7
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-pro-banner__content",
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 20,
      columnNumber: 9
    }
  }, wp.element.createElement("h2", {
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 21,
      columnNumber: 11
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Did you know WPMU DEV Membership includes ", "plugin-cross-sell-textdomain"), wp.element.createElement("span", {
    className: "cross-sell-pro-banner__emph",
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 26,
      columnNumber: 13
    }
  }, (0,external_wp_i18n_namespaceObject.__)("ALL our Pro Plugins?", "plugin-cross-sell-textdomain"))), wp.element.createElement("p", {
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 31,
      columnNumber: 11
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Join to unlock the full toolkit - hosting, reselling, and more.", "plugin-cross-sell-textdomain")), wp.element.createElement(Button, {
    as: "a",
    className: "cross-sell-pro-banner__cta",
    href: getUtmUrl(href, {
      utm_campaign: 'cross-sell_pro-upsell'
    }),
    target: targetBlank ? "_blank" : undefined,
    rel: targetBlank ? "noopener noreferrer" : undefined,
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 38,
      columnNumber: 11
    }
  }, (0,external_wp_i18n_namespaceObject.__)("Get All Pro Plugins & More!", "plugin-cross-sell-textdomain"))), wp.element.createElement("div", {
    className: "cross-sell-pro-banner__vector",
    "aria-hidden": "true",
    __self: pro_plugins_banner_this,
    __source: {
      fileName: pro_plugins_banner_jsxFileName,
      lineNumber: 51,
      columnNumber: 9
    }
  })));
};

;// ./src/components/banners/index.jsx

;// ./node_modules/.pnpm/@wpmudev+react-button@1.1.2/node_modules/@wpmudev/react-button/dist/react-button.esm.js


function react_button_esm_ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? react_button_esm_ownKeys(Object(source), !0).forEach(function (key) {
      react_button_esm_defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : react_button_esm_ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}

function react_button_esm_defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function react_button_esm_objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function react_button_esm_objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = react_button_esm_objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

var react_button_esm_excluded = ["label", "icon", "iconRight", "design", "color", "className", "loading"];

var react_button_esm_Button = function Button(_ref) {
  var label = _ref.label,
      icon = _ref.icon,
      iconRight = _ref.iconRight,
      _ref$design = _ref.design,
      design = _ref$design === void 0 ? 'solid' : _ref$design,
      color = _ref.color,
      className = _ref.className,
      loading = _ref.loading,
      props = react_button_esm_objectWithoutProperties(_ref, react_button_esm_excluded);

  var loader = /*#__PURE__*/external_React_default().createElement("span", {
    className: "sui-icon-loader sui-loading",
    style: {
      position: 'relative'
    },
    "aria-hidden": "true"
  });
  var content = /*#__PURE__*/external_React_default().createElement((external_React_default()).Fragment, null, icon && !iconRight && '' !== icon && /*#__PURE__*/external_React_default().createElement("span", {
    className: 'sui-icon-' + icon,
    "aria-hidden": "true"
  }), label, icon && iconRight && '' !== icon && /*#__PURE__*/external_React_default().createElement("span", {
    className: 'sui-icon-' + icon,
    "aria-hidden": "true"
  }));
  className = "sui-button".concat(iconRight ? ' sui-button-icon-right' : '').concat(className ? ' ' + className : ''); // Set button color.

  switch (color) {
    case 'blue':
    case 'green':
    case 'red':
    case 'orange':
    case 'purple':
    case 'yellow':
    case 'white':
      className += ' sui-button-' + color;
      break;

    case 'gray':
    default:
      className += '';
      break;
  } // Set button style.


  switch (design) {
    case 'ghost':
    case 'outlined':
      className += ' sui-button-' + design;
      break;

    case 'solid':
    default:
      className += '';
      break;
  } // Set loading class.


  if (loading) {
    className += ' sui-button-onload';
  }

  var htmlTag = 'button';

  if (props.href) {
    htmlTag = 'a';
  } else if (props.htmlFor) {
    htmlTag = 'label';
  }

  return /*#__PURE__*/external_React_default().createElement(htmlTag, _objectSpread2({
    className: className,
    disabled: props.disabled || loading
  }, props), loading ? loader : content);
};



;// external ["wp","apiFetch"]
const external_wp_apiFetch_namespaceObject = window["wp"]["apiFetch"];
var external_wp_apiFetch_default = /*#__PURE__*/__webpack_require__.n(external_wp_apiFetch_namespaceObject);
;// ./node_modules/.pnpm/@wpmudev+react-notifications@1.1.1/node_modules/@wpmudev/react-notifications/dist/react-notifications.esm.js


function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}

function _defineProperty$1(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  Object.defineProperty(subClass, "prototype", {
    writable: false
  });
  if (superClass) _setPrototypeOf(subClass, superClass);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

function _possibleConstructorReturn(self, call) {
  if (call && (typeof call === "object" || typeof call === "function")) {
    return call;
  } else if (call !== void 0) {
    throw new TypeError("Derived constructors may only return object or undefined");
  }

  return _assertThisInitialized(self);
}

function _createSuper(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();

  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived),
        result;

    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;

      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }

    return _possibleConstructorReturn(this, result);
  };
}

function react_notifications_esm_ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function react_notifications_esm_objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? react_notifications_esm_ownKeys(Object(source), !0).forEach(function (key) {
      react_notifications_esm_defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : react_notifications_esm_ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}

function react_notifications_esm_defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

function react_notifications_esm_objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

function react_notifications_esm_objectWithoutProperties(source, excluded) {
  if (source == null) return {};

  var target = react_notifications_esm_objectWithoutPropertiesLoose(source, excluded);

  var key, i;

  if (Object.getOwnPropertySymbols) {
    var sourceSymbolKeys = Object.getOwnPropertySymbols(source);

    for (i = 0; i < sourceSymbolKeys.length; i++) {
      key = sourceSymbolKeys[i];
      if (excluded.indexOf(key) >= 0) continue;
      if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
      target[key] = source[key];
    }
  }

  return target;
}

var react_notifications_esm_excluded = ["label", "icon", "iconSize", "design", "color", "className", "loading"];

var ButtonIcon = function ButtonIcon(_ref) {
  var label = _ref.label,
      icon = _ref.icon,
      iconSize = _ref.iconSize,
      _ref$design = _ref.design,
      design = _ref$design === void 0 ? 'solid' : _ref$design,
      color = _ref.color,
      className = _ref.className,
      loading = _ref.loading,
      props = react_notifications_esm_objectWithoutProperties(_ref, react_notifications_esm_excluded);

  var loader = /*#__PURE__*/external_React_default().createElement("span", {
    className: "sui-icon-loader sui-loading",
    style: {
      position: 'relative'
    },
    "aria-hidden": "true"
  });
  var content = /*#__PURE__*/external_React_default().createElement((external_React_default()).Fragment, null, /*#__PURE__*/external_React_default().createElement("span", {
    className: "sui-icon-".concat(icon).concat(iconSize ? ' sui-' + iconSize : ''),
    "aria-hidden": "true"
  }), /*#__PURE__*/external_React_default().createElement("span", {
    className: "sui-screen-reader-text"
  }, label));
  className = "sui-button-icon ".concat(className || ''); // Set button color.

  switch (color) {
    case 'blue':
    case 'green':
    case 'red':
    case 'orange':
    case 'purple':
    case 'yellow':
    case 'white':
      className += ' sui-button-' + color;
      break;

    case 'gray':
    default:
      className += '';
      break;
  } // Set button style.


  switch (design) {
    case 'ghost':
    case 'outlined':
      className += ' sui-button-' + design;
      break;

    case 'solid':
    default:
      className += '';
      break;
  } // Set loading class.


  if (loading) {
    className += ' sui-button-onload';
  }

  var htmlTag = props.href ? 'a' : 'button';
  return /*#__PURE__*/external_React_default().createElement(htmlTag, react_notifications_esm_objectSpread2({
    className: className,
    disabled: props.disabled || loading
  }, props), loading ? loader : content);
};

var Notifications = /*#__PURE__*/function (_Component) {
  _inherits(Notifications, _Component);

  var _super = _createSuper(Notifications);

  function Notifications(props) {
    var _this;

    _classCallCheck(this, Notifications);

    _this = _super.call(this, props);

    _defineProperty$1(_assertThisInitialized(_this), "close", function () {
      _this.setState({
        hide: true
      });

      _this.props.cbFunction ? _this.props.cbFunction() : '';
    });

    _this.state = {
      hide: false
    };
    _this.close = _this.close.bind(_assertThisInitialized(_this));
    return _this;
  }

  _createClass(Notifications, [{
    key: "render",
    value: function render() {
      var _this2 = this;

      var hide = this.state.hide;
      var classMain = 'sui-notice';
      var classIcon = 'sui-notice-icon sui-md';

      switch (this.props.type) {
        case 'info':
        case 'success':
        case 'warning':
        case 'error':
        case 'upsell':
          classMain += ' sui-notice-' + this.props.type;

          if (this.props.loading) {
            classIcon += ' sui-icon-loader sui-loading';
          } else {
            classIcon += ' sui-icon-info';
          }

          break;

        default:
          if (this.props.loading) {
            classIcon += ' sui-icon-loader sui-loading';
          } else {
            classIcon += ' sui-icon-info';
          }

          break;
      }

      var lang = Object.assign({
        dismiss: 'Hide Notification'
      }, this.props.sourceLang);
      var message = /*#__PURE__*/external_React_default().createElement("div", {
        className: "sui-notice-message"
      }, /*#__PURE__*/external_React_default().createElement("span", {
        className: classIcon,
        "aria-hidden": "true"
      }), this.props.children);
      var actions = /*#__PURE__*/external_React_default().createElement("div", {
        className: "sui-notice-actions"
      }, /*#__PURE__*/external_React_default().createElement(ButtonIcon, {
        icon: "check",
        label: lang.dismiss,
        onClick: function onClick(e) {
          return _this2.close(e);
        }
      }));

      if (!hide) {
        return /*#__PURE__*/external_React_default().createElement("div", {
          className: classMain
        }, /*#__PURE__*/external_React_default().createElement("div", {
          className: "sui-notice-content"
        }, message, this.props.dismiss && actions));
      }

      return null;
    }
  }]);

  return Notifications;
}(external_React_namespaceObject.Component);



;// ./src/components/plugins/plugin-card.jsx
function plugin_card_typeof(o) { "@babel/helpers - typeof"; return plugin_card_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, plugin_card_typeof(o); }
var plugin_card_excluded = ["as", "className", "logo", "title", "label", "rating", "rating_count", "active_installs", "description", "features", "url", "active", "installed", "slug", "cta", "path", "extended_view"];
var plugin_card_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/plugins/plugin-card.jsx",
  plugin_card_this = undefined;
function plugin_card_extends() { return plugin_card_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, plugin_card_extends.apply(null, arguments); }
function plugin_card_regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ plugin_card_regeneratorRuntime = function _regeneratorRuntime() { return e; }; var t, e = {}, r = Object.prototype, n = r.hasOwnProperty, o = Object.defineProperty || function (t, e, r) { t[e] = r.value; }, i = "function" == typeof Symbol ? Symbol : {}, a = i.iterator || "@@iterator", c = i.asyncIterator || "@@asyncIterator", u = i.toStringTag || "@@toStringTag"; function define(t, e, r) { return Object.defineProperty(t, e, { value: r, enumerable: !0, configurable: !0, writable: !0 }), t[e]; } try { define({}, ""); } catch (t) { define = function define(t, e, r) { return t[e] = r; }; } function wrap(t, e, r, n) { var i = e && e.prototype instanceof Generator ? e : Generator, a = Object.create(i.prototype), c = new Context(n || []); return o(a, "_invoke", { value: makeInvokeMethod(t, r, c) }), a; } function tryCatch(t, e, r) { try { return { type: "normal", arg: t.call(e, r) }; } catch (t) { return { type: "throw", arg: t }; } } e.wrap = wrap; var h = "suspendedStart", l = "suspendedYield", f = "executing", s = "completed", y = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var p = {}; define(p, a, function () { return this; }); var d = Object.getPrototypeOf, v = d && d(d(values([]))); v && v !== r && n.call(v, a) && (p = v); var g = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(p); function defineIteratorMethods(t) { ["next", "throw", "return"].forEach(function (e) { define(t, e, function (t) { return this._invoke(e, t); }); }); } function AsyncIterator(t, e) { function invoke(r, o, i, a) { var c = tryCatch(t[r], t, o); if ("throw" !== c.type) { var u = c.arg, h = u.value; return h && "object" == plugin_card_typeof(h) && n.call(h, "__await") ? e.resolve(h.__await).then(function (t) { invoke("next", t, i, a); }, function (t) { invoke("throw", t, i, a); }) : e.resolve(h).then(function (t) { u.value = t, i(u); }, function (t) { return invoke("throw", t, i, a); }); } a(c.arg); } var r; o(this, "_invoke", { value: function value(t, n) { function callInvokeWithMethodAndArg() { return new e(function (e, r) { invoke(t, n, e, r); }); } return r = r ? r.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(e, r, n) { var o = h; return function (i, a) { if (o === f) throw Error("Generator is already running"); if (o === s) { if ("throw" === i) throw a; return { value: t, done: !0 }; } for (n.method = i, n.arg = a;;) { var c = n.delegate; if (c) { var u = maybeInvokeDelegate(c, n); if (u) { if (u === y) continue; return u; } } if ("next" === n.method) n.sent = n._sent = n.arg;else if ("throw" === n.method) { if (o === h) throw o = s, n.arg; n.dispatchException(n.arg); } else "return" === n.method && n.abrupt("return", n.arg); o = f; var p = tryCatch(e, r, n); if ("normal" === p.type) { if (o = n.done ? s : l, p.arg === y) continue; return { value: p.arg, done: n.done }; } "throw" === p.type && (o = s, n.method = "throw", n.arg = p.arg); } }; } function maybeInvokeDelegate(e, r) { var n = r.method, o = e.iterator[n]; if (o === t) return r.delegate = null, "throw" === n && e.iterator["return"] && (r.method = "return", r.arg = t, maybeInvokeDelegate(e, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), y; var i = tryCatch(o, e.iterator, r.arg); if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, y; var a = i.arg; return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, y) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, y); } function pushTryEntry(t) { var e = { tryLoc: t[0] }; 1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e); } function resetTryEntry(t) { var e = t.completion || {}; e.type = "normal", delete e.arg, t.completion = e; } function Context(t) { this.tryEntries = [{ tryLoc: "root" }], t.forEach(pushTryEntry, this), this.reset(!0); } function values(e) { if (e || "" === e) { var r = e[a]; if (r) return r.call(e); if ("function" == typeof e.next) return e; if (!isNaN(e.length)) { var o = -1, i = function next() { for (; ++o < e.length;) if (n.call(e, o)) return next.value = e[o], next.done = !1, next; return next.value = t, next.done = !0, next; }; return i.next = i; } } throw new TypeError(plugin_card_typeof(e) + " is not iterable"); } return GeneratorFunction.prototype = GeneratorFunctionPrototype, o(g, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), o(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, u, "GeneratorFunction"), e.isGeneratorFunction = function (t) { var e = "function" == typeof t && t.constructor; return !!e && (e === GeneratorFunction || "GeneratorFunction" === (e.displayName || e.name)); }, e.mark = function (t) { return Object.setPrototypeOf ? Object.setPrototypeOf(t, GeneratorFunctionPrototype) : (t.__proto__ = GeneratorFunctionPrototype, define(t, u, "GeneratorFunction")), t.prototype = Object.create(g), t; }, e.awrap = function (t) { return { __await: t }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, c, function () { return this; }), e.AsyncIterator = AsyncIterator, e.async = function (t, r, n, o, i) { void 0 === i && (i = Promise); var a = new AsyncIterator(wrap(t, r, n, o), i); return e.isGeneratorFunction(r) ? a : a.next().then(function (t) { return t.done ? t.value : a.next(); }); }, defineIteratorMethods(g), define(g, u, "Generator"), define(g, a, function () { return this; }), define(g, "toString", function () { return "[object Generator]"; }), e.keys = function (t) { var e = Object(t), r = []; for (var n in e) r.push(n); return r.reverse(), function next() { for (; r.length;) { var t = r.pop(); if (t in e) return next.value = t, next.done = !1, next; } return next.done = !0, next; }; }, e.values = values, Context.prototype = { constructor: Context, reset: function reset(e) { if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(resetTryEntry), !e) for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t); }, stop: function stop() { this.done = !0; var t = this.tryEntries[0].completion; if ("throw" === t.type) throw t.arg; return this.rval; }, dispatchException: function dispatchException(e) { if (this.done) throw e; var r = this; function handle(n, o) { return a.type = "throw", a.arg = e, r.next = n, o && (r.method = "next", r.arg = t), !!o; } for (var o = this.tryEntries.length - 1; o >= 0; --o) { var i = this.tryEntries[o], a = i.completion; if ("root" === i.tryLoc) return handle("end"); if (i.tryLoc <= this.prev) { var c = n.call(i, "catchLoc"), u = n.call(i, "finallyLoc"); if (c && u) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } else if (c) { if (this.prev < i.catchLoc) return handle(i.catchLoc, !0); } else { if (!u) throw Error("try statement without catch or finally"); if (this.prev < i.finallyLoc) return handle(i.finallyLoc); } } } }, abrupt: function abrupt(t, e) { for (var r = this.tryEntries.length - 1; r >= 0; --r) { var o = this.tryEntries[r]; if (o.tryLoc <= this.prev && n.call(o, "finallyLoc") && this.prev < o.finallyLoc) { var i = o; break; } } i && ("break" === t || "continue" === t) && i.tryLoc <= e && e <= i.finallyLoc && (i = null); var a = i ? i.completion : {}; return a.type = t, a.arg = e, i ? (this.method = "next", this.next = i.finallyLoc, y) : this.complete(a); }, complete: function complete(t, e) { if ("throw" === t.type) throw t.arg; return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), y; }, finish: function finish(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), resetTryEntry(r), y; } }, "catch": function _catch(t) { for (var e = this.tryEntries.length - 1; e >= 0; --e) { var r = this.tryEntries[e]; if (r.tryLoc === t) { var n = r.completion; if ("throw" === n.type) { var o = n.arg; resetTryEntry(r); } return o; } } throw Error("illegal catch attempt"); }, delegateYield: function delegateYield(e, r, n) { return this.delegate = { iterator: values(e), resultName: r, nextLoc: n }, "next" === this.method && (this.arg = t), y; } }, e; }
function plugin_card_asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function plugin_card_asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { plugin_card_asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { plugin_card_asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function plugin_card_slicedToArray(r, e) { return plugin_card_arrayWithHoles(r) || plugin_card_iterableToArrayLimit(r, e) || plugin_card_unsupportedIterableToArray(r, e) || plugin_card_nonIterableRest(); }
function plugin_card_nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function plugin_card_unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return plugin_card_arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? plugin_card_arrayLikeToArray(r, a) : void 0; } }
function plugin_card_arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function plugin_card_iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function plugin_card_arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function plugin_card_objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = plugin_card_objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function plugin_card_objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }






var PluginCard = function PluginCard(_ref) {
  var _ref$as = _ref.as,
    as = _ref$as === void 0 ? "div" : _ref$as,
    _ref$className = _ref.className,
    className = _ref$className === void 0 ? "" : _ref$className,
    logo = _ref.logo,
    title = _ref.title,
    label = _ref.label,
    rating = _ref.rating,
    rating_count = _ref.rating_count,
    active_installs = _ref.active_installs,
    description = _ref.description,
    features = _ref.features,
    url = _ref.url,
    isActiveProp = _ref.active,
    isInstalledProp = _ref.installed,
    slug = _ref.slug,
    _ref$cta = _ref.cta,
    cta = _ref$cta === void 0 ? false : _ref$cta,
    path = _ref.path,
    extended_view = _ref.extended_view,
    delegated = plugin_card_objectWithoutProperties(_ref, plugin_card_excluded);
  var _useState = (0,external_React_namespaceObject.useState)(isInstalledProp),
    _useState2 = plugin_card_slicedToArray(_useState, 2),
    isInstalled = _useState2[0],
    setIsInstalled = _useState2[1];
  var _useState3 = (0,external_React_namespaceObject.useState)(isActiveProp),
    _useState4 = plugin_card_slicedToArray(_useState3, 2),
    isActive = _useState4[0],
    setIsActive = _useState4[1];
  var _useState5 = (0,external_React_namespaceObject.useState)(false),
    _useState6 = plugin_card_slicedToArray(_useState5, 2),
    loading = _useState6[0],
    setLoading = _useState6[1];
  var _useState7 = (0,external_React_namespaceObject.useState)(null),
    _useState8 = plugin_card_slicedToArray(_useState7, 2),
    notification = _useState8[0],
    setNotification = _useState8[1];
  var TagName = as;
  var classes = "cross-sell-card ".concat(className);
  var showNotification = function showNotification(message) {
    var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "success";
    setNotification({
      message: message,
      type: type
    });
    setTimeout(function () {
      return setNotification(null);
    }, 5000); // Hide after 5 seconds
  };
  var handleInstallPlugin = /*#__PURE__*/function () {
    var _ref2 = plugin_card_asyncToGenerator(/*#__PURE__*/plugin_card_regeneratorRuntime().mark(function _callee() {
      var response;
      return plugin_card_regeneratorRuntime().wrap(function _callee$(_context) {
        while (1) switch (_context.prev = _context.next) {
          case 0:
            setLoading(true);
            _context.prev = 1;
            _context.next = 4;
            return external_wp_apiFetch_default()({
              path: window.wpmudev_cross_sell_data.restEndpointInstall,
              method: "POST",
              data: {
                plugin_slug: slug,
                current_slug: window.wpmudev_cross_sell_data.current_slug
              }
            });
          case 4:
            response = _context.sent;
            if (response.success) {
              setIsInstalled(true);
              showNotification(wp.element.createElement(external_React_namespaceObject.Fragment, {
                __self: plugin_card_this,
                __source: {
                  fileName: plugin_card_jsxFileName,
                  lineNumber: 57,
                  columnNumber: 11
                }
              }, wp.element.createElement("b", {
                __self: plugin_card_this,
                __source: {
                  fileName: plugin_card_jsxFileName,
                  lineNumber: 58,
                  columnNumber: 13
                }
              }, (0,external_wp_i18n_namespaceObject.__)(title, "plugin-cross-sell-textdomain")), (0,external_wp_i18n_namespaceObject.__)(" plugin has been installed successfully!", "plugin-cross-sell-textdomain")));
            } else {
              console.error("Installation failed:", response.message);
              showNotification((0,external_wp_i18n_namespaceObject.__)("Installation failed: ".concat(response.message), "plugin-cross-sell-textdomain"), "error");
            }
            _context.next = 12;
            break;
          case 8:
            _context.prev = 8;
            _context.t0 = _context["catch"](1);
            console.error("Error installing plugin:", _context.t0);
            showNotification((0,external_wp_i18n_namespaceObject.__)("Error installing plugin: ".concat(_context.t0.message), "plugin-cross-sell-textdomain"), "error");
          case 12:
            setLoading(false);
          case 13:
          case "end":
            return _context.stop();
        }
      }, _callee, null, [[1, 8]]);
    }));
    return function handleInstallPlugin() {
      return _ref2.apply(this, arguments);
    };
  }();
  var handleActivatePlugin = /*#__PURE__*/function () {
    var _ref3 = plugin_card_asyncToGenerator(/*#__PURE__*/plugin_card_regeneratorRuntime().mark(function _callee2() {
      var response;
      return plugin_card_regeneratorRuntime().wrap(function _callee2$(_context2) {
        while (1) switch (_context2.prev = _context2.next) {
          case 0:
            setLoading(true);
            _context2.prev = 1;
            _context2.next = 4;
            return external_wp_apiFetch_default()({
              path: window.wpmudev_cross_sell_data.restEndpointActivate || "/wpmudev/v1/activate-plugin",
              method: "POST",
              data: {
                plugin_slug: slug,
                current_slug: window.wpmudev_cross_sell_data.current_slug
              }
            });
          case 4:
            response = _context2.sent;
            if (response.success) {
              setIsActive(true);
              showNotification(wp.element.createElement(external_React_namespaceObject.Fragment, {
                __self: plugin_card_this,
                __source: {
                  fileName: plugin_card_jsxFileName,
                  lineNumber: 105,
                  columnNumber: 11
                }
              }, wp.element.createElement("b", {
                __self: plugin_card_this,
                __source: {
                  fileName: plugin_card_jsxFileName,
                  lineNumber: 106,
                  columnNumber: 13
                }
              }, (0,external_wp_i18n_namespaceObject.__)(title, "plugin-cross-sell-textdomain")), (0,external_wp_i18n_namespaceObject.__)(" plugin has been activated successfully!", "plugin-cross-sell-textdomain")));
              setTimeout(function () {
                window.location.reload();
              }, 1000);
            } else {
              console.error("Activation failed:", response.message);
              showNotification((0,external_wp_i18n_namespaceObject.__)("Activation failed: ".concat(response.message), "plugin-cross-sell-textdomain"), "error");
            }
            _context2.next = 12;
            break;
          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](1);
            console.error("Error activating plugin:", _context2.t0);
            showNotification((0,external_wp_i18n_namespaceObject.__)("Error activating plugin: ".concat(_context2.t0.message), "plugin-cross-sell-textdomain"), "error");
          case 12:
            setLoading(false);
          case 13:
          case "end":
            return _context2.stop();
        }
      }, _callee2, null, [[1, 8]]);
    }));
    return function handleActivatePlugin() {
      return _ref3.apply(this, arguments);
    };
  }();
  return wp.element.createElement(external_React_namespaceObject.Fragment, {
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 140,
      columnNumber: 5
    }
  }, notification && wp.element.createElement("div", {
    className: "sui-floating-notices",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 142,
      columnNumber: 9
    }
  }, wp.element.createElement(Notifications, {
    type: notification.type,
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 143,
      columnNumber: 11
    }
  }, wp.element.createElement("p", {
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 144,
      columnNumber: 13
    }
  }, notification.message))), wp.element.createElement(TagName, plugin_card_extends({
    className: classes
  }, TagName === "a" ? {
    href: url,
    target: "_blank"
  } : {}, delegated, {
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 148,
      columnNumber: 7
    }
  }), wp.element.createElement("div", {
    className: "cross-sell-plugin-card-header",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 153,
      columnNumber: 9
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-plugin-card sui-summary-segment",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 154,
      columnNumber: 11
    }
  }, wp.element.createElement("img", {
    src: logo,
    alt: title || "Plugin logo",
    className: "cross-sell-plugin-card__logo",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 155,
      columnNumber: 13
    }
  }), wp.element.createElement("div", {
    className: "cross-sell-plugin-card__content sui-summary-details",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 160,
      columnNumber: 13
    }
  }, wp.element.createElement("h2", {
    className: "cross-sell-plugin-card__title",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 161,
      columnNumber: 15
    }
  }, (0,external_wp_i18n_namespaceObject.__)(title, "plugin-cross-sell-textdomain")), wp.element.createElement("span", {
    className: "cross-sell-plugin-card__subtitle sui-summary-sub",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 164,
      columnNumber: 15
    }
  }, (0,external_wp_i18n_namespaceObject.__)(label, "plugin-cross-sell-textdomain"))))), wp.element.createElement("div", {
    className: "cross-sell-plugin-card-content",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 170,
      columnNumber: 9
    }
  }, extended_view && wp.element.createElement("div", {
    className: "cross-sell-plugin-card-rating",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 172,
      columnNumber: 13
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-plugin-card-rating__stars",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 173,
      columnNumber: 15
    }
  }, wp.element.createElement(StarAltIcon, {
    score: 5,
    maxStars: 5,
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 174,
      columnNumber: 17
    }
  }), (0,external_wp_i18n_namespaceObject.__)(rating, "plugin-cross-sell-textdomain"), " (", (0,external_wp_i18n_namespaceObject.__)(rating_count, "plugin-cross-sell-textdomain"), ")")), wp.element.createElement("span", {
    className: "cross-sell-plugin-card-description",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 181,
      columnNumber: 11
    }
  }, (0,external_wp_i18n_namespaceObject.__)(description, "plugin-cross-sell-textdomain")), features && features.length > 0 && wp.element.createElement("div", {
    className: "cross-sell-plugin-card-features",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 185,
      columnNumber: 13
    }
  }, features.map(function (feature, index) {
    return wp.element.createElement("div", {
      key: index,
      className: "cross-sell-plugin-card-feature",
      __self: plugin_card_this,
      __source: {
        fileName: plugin_card_jsxFileName,
        lineNumber: 187,
        columnNumber: 17
      }
    }, wp.element.createElement(CheckIcon, {
      __self: plugin_card_this,
      __source: {
        fileName: plugin_card_jsxFileName,
        lineNumber: 188,
        columnNumber: 19
      }
    }), (0,external_wp_i18n_namespaceObject.__)(feature, "plugin-cross-sell-textdomain"));
  }))), wp.element.createElement("div", {
    className: "cross-sell-plugin-card-footer ".concat(!extended_view ? "cross-sell-plugin-card-footer--cta-only" : ""),
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 196,
      columnNumber: 9
    }
  }, extended_view && wp.element.createElement("div", {
    className: "cross-sell-plugin-card-footer__installs",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 202,
      columnNumber: 13
    }
  }, (0,external_wp_i18n_namespaceObject.__)("".concat(active_installs, " active installs"), "plugin-cross-sell-textdomain")), cta && wp.element.createElement("div", {
    className: "cross-sell-plugin-card-footer__cta",
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 211,
      columnNumber: 13
    }
  }, !isInstalled ? wp.element.createElement(react_button_esm_Button, {
    label: loading ? (0,external_wp_i18n_namespaceObject.__)("Installing...", "plugin-cross-sell-textdomain") : (0,external_wp_i18n_namespaceObject.__)("Install", "plugin-cross-sell-textdomain"),
    design: "ghost",
    onClick: handleInstallPlugin,
    disabled: loading,
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 213,
      columnNumber: 17
    }
  }) : !isActive ? wp.element.createElement(react_button_esm_Button, {
    label: loading ? (0,external_wp_i18n_namespaceObject.__)("Activating...", "plugin-cross-sell-textdomain") : (0,external_wp_i18n_namespaceObject.__)("Activate", "plugin-cross-sell-textdomain"),
    color: "blue",
    onClick: handleActivatePlugin,
    disabled: loading,
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 224,
      columnNumber: 17
    }
  }) : wp.element.createElement(react_button_esm_Button, {
    label: (0,external_wp_i18n_namespaceObject.__)("Active", "plugin-cross-sell-textdomain"),
    design: "ghost",
    color: "green",
    style: {
      pointerEvents: "none"
    },
    __self: plugin_card_this,
    __source: {
      fileName: plugin_card_jsxFileName,
      lineNumber: 235,
      columnNumber: 17
    }
  })))));
};

;// ./src/components/plugins/plugins.jsx
var plugins_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/components/plugins/plugins.jsx",
  plugins_this = undefined;
function plugins_extends() { return plugins_extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, plugins_extends.apply(null, arguments); }




// Access the localized free plugins data
var MAJOR_PLUGINS_OBJ = window.wpmudev_cross_sell_data.plugins_list.major || [];
var MAJOR_PLUGINS = Object.values(MAJOR_PLUGINS_OBJ);
var MINOR_PLUGINS_OBJ = window.wpmudev_cross_sell_data.plugins_list.minor || [];
var MINOR_PLUGINS = Object.values(MINOR_PLUGINS_OBJ);
var Plugins = function Plugins() {
  return wp.element.createElement(external_React_namespaceObject.Fragment, {
    __self: plugins_this,
    __source: {
      fileName: plugins_jsxFileName,
      lineNumber: 16,
      columnNumber: 5
    }
  }, MAJOR_PLUGINS.map(function (plugin) {
    return wp.element.createElement(PluginCard, plugins_extends({
      key: plugin.slug,
      className: "cross-sell-card--major",
      cta: true,
      extended_view: true
    }, plugin, {
      __self: plugins_this,
      __source: {
        fileName: plugins_jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }
    }));
  }), MINOR_PLUGINS.map(function (plugin) {
    return wp.element.createElement(PluginCard, plugins_extends({
      key: plugin.slug,
      className: "cross-sell-card--minor",
      cta: true
    }, plugin, {
      __self: plugins_this,
      __source: {
        fileName: plugins_jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }
    }));
  }));
};

;// ./src/components/plugins/index.jsx


;// ./src/cross-sell-page/wrapper.jsx
var wrapper_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/cross-sell-page/wrapper.jsx",
  wrapper_this = undefined;








var Wrapper = function Wrapper() {
  return wp.element.createElement("div", {
    className: "wpmudev-cross-sell-page",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 12,
      columnNumber: 5
    }
  }, wp.element.createElement("div", {
    className: "sui-box",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }
  }, wp.element.createElement("div", {
    className: "sui-box-body",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 14,
      columnNumber: 9
    }
  }, wp.element.createElement(HeroSection, {
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 15,
      columnNumber: 11
    }
  }), wp.element.createElement("div", {
    className: "sui-box",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 16,
      columnNumber: 11
    }
  }, wp.element.createElement("div", {
    className: "sui-box-body",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-wrapper",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 18,
      columnNumber: 15
    }
  }, wp.element.createElement(Section, {
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 19,
      columnNumber: 17
    }
  }, wp.element.createElement("div", {
    className: "cross-sell-grid",
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 20,
      columnNumber: 19
    }
  }, wp.element.createElement(Plugins, {
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 21,
      columnNumber: 21
    }
  }))), wp.element.createElement(ProPluginsBanner, {
    href: "https://wpmudev.com/plugins/",
    targetBlank: true,
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 24,
      columnNumber: 17
    }
  })))), wp.element.createElement(Reviews, {
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 31,
      columnNumber: 11
    }
  }), wp.element.createElement(Footer, {
    __self: wrapper_this,
    __source: {
      fileName: wrapper_jsxFileName,
      lineNumber: 32,
      columnNumber: 11
    }
  }))));
};

;// ./src/cross-sell-page/main.jsx
var main_jsxFileName = "/opt/atlassian/pipelines/agent/build/src/cross-sell-page/main.jsx";



var domElement = document.getElementById(window.wpmudev_cross_sell_data.dom_element_id);
if (domElement) {
  if (external_wp_element_namespaceObject.createRoot) {
    (0,external_wp_element_namespaceObject.createRoot)(domElement).render(wp.element.createElement(external_wp_element_namespaceObject.StrictMode, {
      __self: undefined,
      __source: {
        fileName: main_jsxFileName,
        lineNumber: 12,
        columnNumber: 7
      }
    }, wp.element.createElement(Wrapper, {
      __self: undefined,
      __source: {
        fileName: main_jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }
    })));
  } else {
    (0,external_wp_element_namespaceObject.render)(wp.element.createElement(external_wp_element_namespaceObject.StrictMode, {
      __self: undefined,
      __source: {
        fileName: main_jsxFileName,
        lineNumber: 18,
        columnNumber: 7
      }
    }, wp.element.createElement(Wrapper, {
      __self: undefined,
      __source: {
        fileName: main_jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }
    })), domElement);
  }
}
/******/ })()
;
//# sourceMappingURL=crosssellpage.js.map